package io.cts.mod.sbapp.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cts.mod.sbapp.bean.Mentor;

@Repository
public interface MentorRepository extends CrudRepository<Mentor, Long> {
//	List<Mentor> findById(long id);
	
//	@Query("Select c From Customer c where c.name = :name and c.age = :age")
//	Customer findByNameAndAge(@Param("name") String name, @Param("age") Integer age);
	
}




