package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.MentorWallet;

public interface MentorWalletService {
	
	public MentorWallet insertMentorWallet(MentorWallet wallet);
	public Optional<MentorWallet> findMentorWalletById(long id);
	public boolean deleteMenorWalletById(long id);
	
	public List<MentorWallet> getAllMentorsWalletsAmount();
	public void updateMentorWallet(long id,MentorWallet wallet);

}
