package io.cts.mod.sbapp.model;

public class UserOngoingTrainings {

	private long trainingId;
	private String courseName;
	private String mentorName;
	private int progress;
	private int duration;
	private String dateOfCompletion;

	public UserOngoingTrainings() {
		super();
	}

	public UserOngoingTrainings(long trainingId, String courseName, String mentorName, int progress, int duration,
			String dateOfCompletion) {
		super();
		this.trainingId = trainingId;
		this.courseName = courseName;
		this.mentorName = mentorName;
		this.progress = progress;
		this.duration = duration;
		this.dateOfCompletion = dateOfCompletion;
	}

	public long getTrainingId() {
		return trainingId;
	}

	public String getCourseName() {
		return courseName;
	}

	public String getMentorName() {
		return mentorName;
	}

	public int getProgress() {
		return progress;
	}

	public int getDuration() {
		return duration;
	}

	public String getDateOfCompletion() {
		return dateOfCompletion;
	}

	public void setTrainingId(long trainingId) {
		this.trainingId = trainingId;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void setDateOfCompletion(String dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}

	@Override
	public String toString() {
		return "UserOngoingTrainings [trainingId=" + trainingId + ", courseName=" + courseName + ", mentorName="
				+ mentorName + ", progress=" + progress + ", duration=" + duration + ", dateOfCompletion="
				+ dateOfCompletion + "]";
	}

}
