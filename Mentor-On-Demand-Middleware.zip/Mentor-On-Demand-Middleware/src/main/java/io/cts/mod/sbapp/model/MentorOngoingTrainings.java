package io.cts.mod.sbapp.model;

public class MentorOngoingTrainings {

	private long mentorId;
	private String courseName;
	private int numOfAttendees;
	private int durationOfCoures;
	private String timeOfTraining;
	private int currentRating;
	private int currentSlot;
	private double totalPayment;

	public MentorOngoingTrainings() {
		super();
	}

	public MentorOngoingTrainings(long mentorId, String courseName, int numOfAttendees, int durationOfCoures,
			String timeOfTraining, int currentRating, int currentSlot, double totalPayment) {
		super();
		this.mentorId = mentorId;
		this.courseName = courseName;
		this.numOfAttendees = numOfAttendees;
		this.durationOfCoures = durationOfCoures;
		this.timeOfTraining = timeOfTraining;
		this.currentRating = currentRating;
		this.currentSlot = currentSlot;
		this.totalPayment = totalPayment;
	}

	public long getMentorId() {
		return mentorId;
	}

	public String getCourseName() {
		return courseName;
	}

	public int getNumOfAttendees() {
		return numOfAttendees;
	}

	public int getDurationOfCoures() {
		return durationOfCoures;
	}

	public String getTimeOfTraining() {
		return timeOfTraining;
	}

	public int getCurrentRating() {
		return currentRating;
	}

	public int getCurrentSlot() {
		return currentSlot;
	}

	public double getTotalPayment() {
		return totalPayment;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setNumOfAttendees(int numOfAttendees) {
		this.numOfAttendees = numOfAttendees;
	}

	public void setDurationOfCoures(int durationOfCoures) {
		this.durationOfCoures = durationOfCoures;
	}

	public void setTimeOfTraining(String timeOfTraining) {
		this.timeOfTraining = timeOfTraining;
	}

	public void setCurrentRating(int currentRating) {
		this.currentRating = currentRating;
	}

	public void setCurrentSlot(int currentSlot) {
		this.currentSlot = currentSlot;
	}

	public void setTotalPayment(double totalPayment) {
		this.totalPayment = totalPayment;
	}

	@Override
	public String toString() {
		return "MentorOngoingTrainings [mentorId=" + mentorId + ", courseName=" + courseName + ", numOfAttendees="
				+ numOfAttendees + ", durationOfCoures=" + durationOfCoures + ", timeOfTraining=" + timeOfTraining
				+ ", currentRating=" + currentRating + ", currentSlot=" + currentSlot + ", totalPayment=" + totalPayment
				+ "]";
	}

}
