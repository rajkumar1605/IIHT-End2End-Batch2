package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "user_payment_table")
public class UserPayments {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Column(name = "user_account_number")
	private long userAccount;

	@NonNull
	@Size(max = 50)
	@Column(name = "user_IFSC")
	private String userIFSC;

	@NonNull
	@Column(name = "recipient_account_number")
	private long recipientAccount;

	@NonNull
	@Size(max = 50)
	@Column(name = "recipient_IFSC")
	private String recipientIFSC;

	@NonNull
	@Size(max = 50)
	@Column(name = "recipient_name")
	private String recipientName;

	@NonNull
	@Column(name = "amount")
	private double amount;

	public UserPayments() {
		super();
	}

	public UserPayments(long id, long userAccount, @Size(max = 50) String userIFSC, long recipientAccount,
			@Size(max = 50) String recipientIFSC, @Size(max = 50) String recipientName, double amount) {
		super();
		this.id = id;
		this.userAccount = userAccount;
		this.userIFSC = userIFSC;
		this.recipientAccount = recipientAccount;
		this.recipientIFSC = recipientIFSC;
		this.recipientName = recipientName;
		this.amount = amount;
	}

	public long getId() {
		return id;
	}

	public long getUserAccount() {
		return userAccount;
	}

	public String getUserIFSC() {
		return userIFSC;
	}

	public long getRecipientAccount() {
		return recipientAccount;
	}

	public String getRecipientIFSC() {
		return recipientIFSC;
	}

	public String getRecipientName() {
		return recipientName;
	}

	public double getAmount() {
		return amount;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setUserAccount(long userAccount) {
		this.userAccount = userAccount;
	}

	public void setUserIFSC(String userIFSC) {
		this.userIFSC = userIFSC;
	}

	public void setRecipientAccount(long recipientAccount) {
		this.recipientAccount = recipientAccount;
	}

	public void setRecipientIFSC(String recipientIFSC) {
		this.recipientIFSC = recipientIFSC;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "UserPayments [id=" + id + ", userAccount=" + userAccount + ", userIFSC=" + userIFSC
				+ ", recipientAccount=" + recipientAccount + ", recipientIFSC=" + recipientIFSC + ", recipientName="
				+ recipientName + ", amount=" + amount + "]";
	}

}
