package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.Trainings;

public interface TrainingsService {
	
	public Trainings insertTrainings(Trainings train);
	public Trainings insertFromUser(Trainings train);
	public List<Trainings> getAllTrainings();
	public Optional<Trainings> findTrainings(long id);
	public void updateTrainingsDetails(long id,Trainings train);
	public boolean deleteTrainings(long id);
	
	public List<Trainings> getByCreatedStatusAndMentorId(String status, long mid);
	public Optional<Trainings> getByCreatedStatusAndMentorIdAndTrainingId(String status, long mid,long cid);
	public List<Trainings> getByInprogressStatusAndMentorId(String status,long mid);
	public List<Trainings> getByCompletedStatusAndMentorId(String status,long mid);	
	public List<Trainings> getByInprogressStatusAndUserId(String status,long uid);
	public List<Trainings> getByStatusAndUserId(String status,long uid);
	
	public List<Trainings> getByCreatedStatusAndTrainingIdAndStartTime(String status,long ctId,String startTime);
	public List<Trainings> getByCourseTechIdAndMentorId(long ctId,long mid);
}
