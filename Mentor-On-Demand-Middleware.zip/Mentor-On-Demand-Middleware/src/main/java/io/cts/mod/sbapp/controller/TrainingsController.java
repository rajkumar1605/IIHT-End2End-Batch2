package io.cts.mod.sbapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.service.TrainingsService;

@CrossOrigin(origins = "http://localhost:4200") 
@RestController
@RequestMapping(path = "/trainings")
public class TrainingsController {

	@Autowired
	private TrainingsService trainingService;

	@PostMapping(path = "/inserttraining/{mid}", headers = "Accept=application/json")               /* By mentor */
	public void insertTraining(@PathVariable("mid") long id,@RequestBody Trainings train) {

		Trainings tr = new Trainings();
		
		tr.setUserId(train.getUserId());   /* Not here, this training id should be kept in user table as the training id he is taking, mentor id should also be taken to update the progress */
	  /*tr.setMentorId(train.getMentorId());     set the current mentor Id from the session or take it when mentor logs in*/
		tr.setMentorId(id);
		tr.setCourseTechId(train.getCourseTechId());
		tr.setCourseFacilities(train.getCourseFacilities());
		tr.setNumOfAttendees(train.getNumOfAttendees());
		tr.setCourseDuration(train.getCourseDuration());
		tr.setCurrentRating(train.getCurrentRating());
		tr.setStatus(train.getStatus());
		tr.setProgress(train.getProgress());
		tr.setMaybeStartTime(train.getMaybeStartTime());
		tr.setStartDate(train.getStartDate());
		tr.setEndDate(train.getEndDate());
		tr.setStartTime(train.getStartTime());
		tr.setEndTime(train.getEndTime());
		tr.setExpectedAmount(train.getExpectedAmount());
		tr.setAmountReceived(train.getAmountReceived());

		trainingService.insertTrainings(tr);

//			{  "courseTechId":1,"courseFacilities":"PPT","courseDuration":"5months","maybeStartTime":"4pm","expectedAmount":25656.99   }
//			 {   "userId":2,"mentorId":4,"courseName":"Java","courseFacilities":"PPT","numOfAttendees":50,"courseDuration":"4months","trainingTime":"4hours","currentRating":5,"status":"Inprogress","progress":"50%","startDate":"23/09/2019","endDate":"31/05/220","maybeStartTime":"4pm","startTime":"5pm","endTime":"9pm","expectedAmount":25656.99,"amountReceived":26000.00   }

	}

	@GetMapping(path = "/getalltrainings")
	public List<Trainings> getAllTrainings() {
		return trainingService.getAllTrainings();
	}

	@GetMapping(path = "/gettrainingbyid/{id}")
	public Optional<Trainings> getTrainingsById(@PathVariable long id) {
		return trainingService.findTrainings(id);
	}
	
	@PutMapping(path = "/updatetraining/{id}")
	public ResponseEntity<Trainings> updateTrainingsDetails(@PathVariable("id") long id, @RequestBody Trainings train) {
		trainingService.updateTrainingsDetails(id, train);
		return new ResponseEntity<>(HttpStatus.OK);
		// return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@DeleteMapping(path = "/deletetraining/{id}")
	public ResponseEntity<String> deleteTrainingById(@PathVariable("id") long id) {

		/* delete all records of this mentor(add later) */

		trainingService.deleteTrainings(id);

		return new ResponseEntity<>("Trainings details deleted!", HttpStatus.OK);

//			return new ResponseEntity<>("Mentor details are not deleted!", HttpStatus.NOT_FOUND);

	}

}


