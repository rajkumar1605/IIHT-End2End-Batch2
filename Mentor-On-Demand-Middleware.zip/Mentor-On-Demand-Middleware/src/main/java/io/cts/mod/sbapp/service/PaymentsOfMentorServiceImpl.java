package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.PaymentsOfMentor;
import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.model.MentorPayment;
import io.cts.mod.sbapp.repository.PaymentsOfMentorRepository;

@Service
public class PaymentsOfMentorServiceImpl implements PaymentsOfMentorService {
	
	@Autowired
	private PaymentsOfMentorRepository repository;
	
	@Override
	public PaymentsOfMentor insertPaymentsOfMentor(PaymentsOfMentor pay) {
		return repository.save(pay);
	}

	@Override
	public List<PaymentsOfMentor> getAllPaymentsOfMentor() {
		List<PaymentsOfMentor> mentorPay=new ArrayList<>();
		repository.findAll().forEach(mentorPay::add);
		return mentorPay;
	}

	@Override
	public Optional<PaymentsOfMentor> findPaymentsOfMentorById(long id) {
		return repository.findById(id);
	}

	@Override
	public void updatePaymentsOfMentorDetails(long id, PaymentsOfMentor pay) {
	Optional<PaymentsOfMentor> payData = findPaymentsOfMentorById(id);
	
	if(payData.isPresent()) {
		
		PaymentsOfMentor p=payData.get();
		
		long mentorId,trainingId;
		double amount;
		int currentSlot;
		String txnType,dateTime,status;
		
		mentorId=pay.getMentorId();
		trainingId=pay.getTrainingId();
		currentSlot=pay.getCurrentSlot();
		txnType=pay.getTxnType();
		dateTime=pay.getTxnType();
		status=pay.getPaymentStatus();
		amount=pay.getAmountOfThisTraining();
		
		if(mentorId!=0) {
			p.setMentorId(mentorId);
		}
		else {
			p.setMentorId(p.getMentorId());
		}
		if(trainingId!=0) {
			p.setTrainingId(trainingId);
		}
		else {
			p.setTrainingId(p.getTrainingId());
		}
		if(currentSlot!=0) {
			p.setCurrentSlot(currentSlot);
		}
		else {
			p.setCurrentSlot(p.getCurrentSlot());
		}
		if(txnType!=null) {
			p.setTxnType(txnType);
		}else {
			p.setTxnType(p.getTxnType());
		}
		if(dateTime!=null) {
			p.setDateTime(dateTime);
		}
		else {
			p.setDateTime(p.getTxnType());
		}
		if(status!=null) {
			p.setPaymentStatus(status);
		}else {
			p.setPaymentStatus(p.getPaymentStatus());
		}
		if(amount!=0) {
			p.setAmountOfThisTraining(amount);
		}
		else {
			p.setAmountOfThisTraining(p.getAmountOfThisTraining());
		}
	
		repository.save(p);
	}
	

}

	@Override
	public boolean deletePaymentsOfMentorById(long id) {
		repository.deleteById(id);
		Optional<PaymentsOfMentor> pom = findPaymentsOfMentorById(id);
		if(pom.isPresent()) {
			return false;
		}
		else {
			return true;
		}
	}

	@Override
	public List<PaymentsOfMentor> getMentorPayment(long id) {
		return repository.findByMentorIdForPayments(id);
	}

//	@Override
//	public Optional<PaymentsOfMentor> getByTrainingIdForCurrentTrainings(long id) {	
//		return repository.findByTrainingIdForCurrentTrainings(id);
//	}
	
	@Override
	public Optional<PaymentsOfMentor> getByTrainingIdForCurrentTrainings(long id) {	
		return repository.findByTrainingId(id);
	}

}
