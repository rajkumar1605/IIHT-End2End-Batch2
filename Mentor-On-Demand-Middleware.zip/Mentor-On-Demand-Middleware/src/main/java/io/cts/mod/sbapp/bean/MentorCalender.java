package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "mentor_calender_table")  /* specific for one mentor */
public class MentorCalender {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Column(name = "mentor_id")
	private long mentorId;

	@NonNull
	@Column(name = "mentor_course_ids")
	private long mentorCourseIds;

	@NonNull
	@Size(max = 50)
	@Column(name = "start_time")
	private String startTime;

	@NonNull
	@Size(max = 50)
	@Column(name = "end_time")
	private String endTime;

	@NonNull
	@Size(max = 50)
	@Column(name = "start_date")
	private String startDate;

	@NonNull
	@Size(max = 50)
	@Column(name = "end_date")
	private String endDate;

	public MentorCalender() {
		super();
	}

	public MentorCalender(long id, @Size(max = 50) long mentorId, @Size(max = 50) long mentorCourseIds,
			@Size(max = 50) String startTime, @Size(max = 50) String endTime, @Size(max = 50) String startDate,
			@Size(max = 50) String endDate) {
		super();
		this.id = id;
		this.mentorId = mentorId;
		this.mentorCourseIds = mentorCourseIds;
		this.startTime = startTime;
		this.endTime = endTime;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getMentorId() {
		return mentorId;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	public long getMentorCourseIds() {
		return mentorCourseIds;
	}

	public void setMentorCourseIds(long mentorCourseIds) {
		this.mentorCourseIds = mentorCourseIds;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "MentorCalender [id=" + id + ", mentorId=" + mentorId + ", mentorCourseIds=" + mentorCourseIds
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", startDate=" + startDate + ", endDate="
				+ endDate + "]";
	}

}
