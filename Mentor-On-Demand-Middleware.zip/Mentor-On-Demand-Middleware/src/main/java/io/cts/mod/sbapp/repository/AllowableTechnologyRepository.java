package io.cts.mod.sbapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cts.mod.sbapp.bean.AllowableTechnology;

@Repository
public interface AllowableTechnologyRepository extends CrudRepository<AllowableTechnology, Long> {

}
