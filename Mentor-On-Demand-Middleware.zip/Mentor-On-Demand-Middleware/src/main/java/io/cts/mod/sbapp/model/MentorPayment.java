package io.cts.mod.sbapp.model;

public class MentorPayment {

	private long mentorId;
	private long trainingsId;
	private String courseName;
	private int duration;
	private String status;
	private int currentSlot;

	private double expectedRemainingAmount;

	public MentorPayment() {
		super();
	}

	public MentorPayment(long mentorId, long trainingsId, String courseName, int duration, String status,
			int currentSlot, double expectedRemainingAmount) {
		super();
		this.mentorId = mentorId;
		this.trainingsId = trainingsId;
		this.courseName = courseName;
		this.duration = duration;
		this.status = status;
		this.currentSlot = currentSlot;
		this.expectedRemainingAmount = expectedRemainingAmount;
	}

	public long getMentorId() {
		return mentorId;
	}

	public long getTrainingsId() {
		return trainingsId;
	}

	public String getCourseName() {
		return courseName;
	}

	public int getDuration() {
		return duration;
	}

	public String getStatus() {
		return status;
	}

	public int getCurrentSlot() {
		return currentSlot;
	}

	public double getExpectedRemainingAmount() {
		return expectedRemainingAmount;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	public void setTrainingsId(long trainingsId) {
		this.trainingsId = trainingsId;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setCurrentSlot(int currentSlot) {
		this.currentSlot = currentSlot;
	}

	public void setExpectedRemainingAmount(double expectedRemainingAmount) {
		this.expectedRemainingAmount = expectedRemainingAmount;
	}

	@Override
	public String toString() {
		return "MentorPayment [mentorId=" + mentorId + ", trainingsId=" + trainingsId + ", courseName=" + courseName
				+ ", duration=" + duration + ", status=" + status + ", currentSlot=" + currentSlot
				+ ", expectedRemainingAmount=" + expectedRemainingAmount + "]";
	}

}
