package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.MentorWallet;
import io.cts.mod.sbapp.repository.MentorWalletRepository;

@Service
public class MentorWalletServiceImpl implements MentorWalletService {

	@Autowired
	private MentorWalletRepository repository;

	@Override
	public MentorWallet insertMentorWallet(MentorWallet wallet) {
		return repository.save(wallet);
	}

	@Override
	public Optional<MentorWallet> findMentorWalletById(long id) {
		return repository.findById(id);
	}

	@Override
	public List<MentorWallet> getAllMentorsWalletsAmount(){
		List<MentorWallet> mentorWallet = new ArrayList<>();
		repository.findAll().forEach(mentorWallet::add);
		return mentorWallet;
	}

	@Override
	public void updateMentorWallet(long id, MentorWallet wallet) {
		Optional<MentorWallet> mentorWalletData = findMentorWalletById(id);

		if (mentorWalletData.isPresent()) {
			MentorWallet mtrwa = mentorWalletData.get();

			long mentorId = wallet.getMentorId();
			double withdrawnMoney = wallet.getWithdrawnMoney();
			double wal = wallet.getWallet();

			if (mentorId != 0) {
				mtrwa.setMentorId(mentorId);
			} else {
				mtrwa.setMentorId(mtrwa.getMentorId());
			}
			if (withdrawnMoney != 0) {
				mtrwa.setWithdrawnMoney(withdrawnMoney);
			} else {
				mtrwa.setWithdrawnMoney(mtrwa.getWithdrawnMoney());
			}
			if (wal != 0) {
				mtrwa.setWallet(wal);
			} else {
				mtrwa.setWallet(mtrwa.getWallet());
			}
			repository.save(mtrwa);

		}

	}

	@Override
	public boolean deleteMenorWalletById(long id) {
		repository.deleteById(id);
		Optional<MentorWallet> mtw = findMentorWalletById(id);
		if (mtw.isPresent()) {
			return false;
		} else {
			return true;
		}
	}

}
