package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.MentorStatus;
import io.cts.mod.sbapp.repository.MentorStatusRepository;

@Service
public class MentorStatusServiceImpl implements MentorStatusService{
	
	@Autowired
	private MentorStatusRepository repository;
	
	@Override
	public MentorStatus insertMentorStatus(MentorStatus status) {
		return repository.save(status);		
	}

	@Override
	public Optional<MentorStatus> findMentorStatusById(long id) {
		return repository.findById(id);
	}

	@Override
	public List<MentorStatus> getAllMentorsStatus() {
		List<MentorStatus> mentorStatus = new ArrayList<>();
		repository.findAll().forEach(mentorStatus::add);	
		return mentorStatus;
	}

	@Override
	public void updateMentorStatus(long id, MentorStatus mtrStatus) {
		
		Optional<MentorStatus> mentorStatusData=findMentorStatusById(id);
		
		if(mentorStatusData.isPresent()) {
			MentorStatus mtrst=mentorStatusData.get();
			
			String active=mtrStatus.getActive();
			long courseId=mtrStatus.getCourseId();
			int totalTraining=mtrStatus.getTotalTraining();
			int specificTrainNum=mtrStatus.getNumSpecificTech();
			
			if(active!=null) {
				mtrst.setActive(active);
			}else {
				mtrst.setActive(mtrst.getActive());
			}
			if(courseId!=0) {
				mtrst.setCourseId(courseId);
			}else {
				mtrst.setCourseId(mtrst.getCourseId());
			}
			if(totalTraining!=0) {
				mtrst.setTotalTraining(totalTraining);
			}else {
				mtrst.setTotalTraining(mtrst.getTotalTraining());
			}
			if(specificTrainNum!=0) {
				mtrst.setNumSpecificTech(specificTrainNum);
			}else {
				mtrst.setNumSpecificTech(mtrst.getNumSpecificTech());
			}
			
			repository.save(mtrst);
		
		}
		
	}
	
	@Override
	public boolean deleteMenorStatusById(long id) {
		repository.deleteById(id);
		Optional<MentorStatus> mts=findMentorStatusById(id);
		if(mts.isPresent()) {
			return false;
		}
		else {
			return true;
		}
	}

}
