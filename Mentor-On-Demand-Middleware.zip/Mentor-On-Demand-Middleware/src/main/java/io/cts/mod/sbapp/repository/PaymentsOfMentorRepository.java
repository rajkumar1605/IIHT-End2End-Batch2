package io.cts.mod.sbapp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.cts.mod.sbapp.bean.PaymentsOfMentor;

@Repository
public interface PaymentsOfMentorRepository extends CrudRepository<PaymentsOfMentor,Long> {
	
	@Query("Select p From PaymentsOfMentor p where p.mentorId = :mentorid")
	List<PaymentsOfMentor> findByMentorIdForPayments(@Param("mentorid")long id);
	
	Optional<PaymentsOfMentor> findByTrainingId(long id);
/* OR	@Query("Select p From PaymentsOfMentor p where p.trainingId = :trainingid")
	    Optional<PaymentsOfMentor> findByTrainingIdForCurrentTrainings(@Param("trainingid")long id); */
	
}
