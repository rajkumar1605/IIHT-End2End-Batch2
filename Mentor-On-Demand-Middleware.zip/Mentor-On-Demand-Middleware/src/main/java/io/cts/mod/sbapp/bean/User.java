package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "user_table")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Size(max = 50)
	@Column(name = "first_name")
	private String firstName;

	@NonNull
	@Size(max = 50)
	@Column(name = "last_name")
	private String lastName;

	@NonNull
	@Size(max = 50)
	@Column(name = "gender")
	private String gender;

	@NonNull
	@Size(max = 50)
	@Column(name = "area_of_interest")
	private String areaOfInterest;

	@NonNull
	@Size(max = 50)
	@Column(name = "education")
	private String education;

	@NonNull
	@Size(max = 50)
	@Column(name = "contact_number")
	private String contactNumber;

	@NonNull
	@Size(max = 50)
	@Column(name = "email_id")
	private String emailId;

	@NonNull
	@Size(max = 50)
	@Column(name = "password")
	private String password;

	@NonNull
	@Size(max = 50)
	@Column(name = "status")
	private String active;

	@NonNull
	@Size(max = 50)
	@Column(name = "security_question")
	private String securityQuestion;

	@NonNull
	@Size(max = 50)
	@Column(name = "own_security_question")
	private String ownSecurityQuestion;

	@NonNull
	@Size(max = 50)
	@Column(name = "security_answer")
	private String securityAnswer;

	public User() {
		super();
	}

	public User(long id, @Size(max = 50) String firstName, @Size(max = 50) String lastName,
			@Size(max = 50) String gender, @Size(max = 50) String areaOfInterest, @Size(max = 50) String education,
			@Size(max = 50) String contactNumber, @Size(max = 50) String emailId, @Size(max = 50) String password,
			@Size(max = 50) String active, @Size(max = 50) String securityQuestion,
			@Size(max = 50) String ownSecurityQuestion, @Size(max = 50) String securityAnswer) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.areaOfInterest = areaOfInterest;
		this.education = education;
		this.contactNumber = contactNumber;
		this.emailId = emailId;
		this.password = password;
		this.active = active;
		this.securityQuestion = securityQuestion;
		this.ownSecurityQuestion = ownSecurityQuestion;
		this.securityAnswer = securityAnswer;
	}

	public long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getGender() {
		return gender;
	}

	public String getAreaOfInterest() {
		return areaOfInterest;
	}

	public String getEducation() {
		return education;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public String getPassword() {
		return password;
	}

	public String getActive() {
		return active;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public String getOwnSecurityQuestion() {
		return ownSecurityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setAreaOfInterest(String areaOfInterest) {
		this.areaOfInterest = areaOfInterest;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public void setOwnSecurityQuestion(String ownSecurityQuestion) {
		this.ownSecurityQuestion = ownSecurityQuestion;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender
				+ ", areaOfInterest=" + areaOfInterest + ", education=" + education + ", contactNumber=" + contactNumber
				+ ", emailId=" + emailId + ", password=" + password + ", active=" + active + ", securityQuestion="
				+ securityQuestion + ", ownSecurityQuestion=" + ownSecurityQuestion + ", securityAnswer="
				+ securityAnswer + "]";
	}

}
