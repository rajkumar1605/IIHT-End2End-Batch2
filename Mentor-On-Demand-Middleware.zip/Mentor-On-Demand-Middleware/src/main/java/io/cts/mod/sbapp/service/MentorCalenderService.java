package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.MentorCalender;

public interface MentorCalenderService {
	
	public MentorCalender insertMentorCalender(MentorCalender mc);
	public List<MentorCalender> getAllMentorCalender();
	public Optional<MentorCalender> findMentorCalenderById(long id);
	public void updateMentorCalenderDetails(long id,MentorCalender mc);
	public boolean deleteMentorCalenderById(long id);
	
}
