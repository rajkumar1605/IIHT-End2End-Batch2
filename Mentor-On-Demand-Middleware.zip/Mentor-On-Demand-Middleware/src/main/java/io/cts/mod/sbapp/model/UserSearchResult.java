package io.cts.mod.sbapp.model;

public class UserSearchResult {

	private String mentorName;
	private int yoe;
	private int totalNumOfTrainings;
	private int numOfSpecificTech;
	private int rating;
	private double feeCharged;

	public UserSearchResult() {
		super();
	}

	public String getMentorName() {
		return mentorName;
	}

	public int getYoe() {
		return yoe;
	}

	public int getTotalNumOfTrainings() {
		return totalNumOfTrainings;
	}

	public int getNumOfSpecificTech() {
		return numOfSpecificTech;
	}

	public int getRating() {
		return rating;
	}

	public double getFeeCharged() {
		return feeCharged;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public void setYoe(int yoe) {
		this.yoe = yoe;
	}

	public void setTotalNumOfTrainings(int totalNumOfTrainings) {
		this.totalNumOfTrainings = totalNumOfTrainings;
	}

	public void setNumOfSpecificTech(int numOfSpecificTech) {
		this.numOfSpecificTech = numOfSpecificTech;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public void setFeeCharged(double feeCharged) {
		this.feeCharged = feeCharged;
	}

	@Override
	public String toString() {
		return "UserSearchResult [mentorName=" + mentorName + ", yoe=" + yoe + ", totalNumOfTrainings="
				+ totalNumOfTrainings + ", numOfSpecificTech=" + numOfSpecificTech + ", rating=" + rating
				+ ", feeCharged=" + feeCharged + "]";
	}

}
