package io.cts.mod.sbapp.model;

public class UserConfirmedTrainings {

	private String courseName;
	private String mentorName;
	private int duration;
	private String startDate;
	private double money;

	public UserConfirmedTrainings() {
		super();
	}

	public UserConfirmedTrainings(String courseName, String mentorName, int duration, String startDate, double money) {
		super();
		this.courseName = courseName;
		this.mentorName = mentorName;
		this.duration = duration;
		this.startDate = startDate;
		this.money = money;
	}

	public String getCourseName() {
		return courseName;
	}

	public String getMentorName() {
		return mentorName;
	}

	public int getDuration() {
		return duration;
	}

	public String getStartDate() {
		return startDate;
	}

	public double getMoney() {
		return money;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	@Override
	public String toString() {
		return "UserConfirmedTrainings [courseName=" + courseName + ", mentorName=" + mentorName + ", duration="
				+ duration + ", startDate=" + startDate + ", money=" + money + "]";
	}

}
