package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "trainings_table") /* ongoing training table(within that 6 status */
public class Trainings {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "user_id")
	private long userId;

	/*
	 * For one course from one mentor there can be multiple users so, when mentor
	 * creates a course that row with user fields will be empty. And when user wants
	 * that course take an instance of that mentor row, create one new row and add
	 * user id with all user fields. Number of attendees will be added in that one
	 * empty row.
	 */

	@NonNull
	@Column(name = "mentor_id")
	private long mentorId;

	@NonNull
	@Column(name = "course_tech_id")
	private long courseTechId;

	@NonNull
	@Size(max = 50)
	@Column(name = "course_facilities")
	private String courseFacilities;

//	@Min(value = 1, message = "Must be equal or greater than 1")
//	@Max(value = 60, message = "Must be equal or less than 60")
	@Column(name = "num_of_attendees")
	private int numOfAttendees;

	@NonNull
	@Column(name = "duration_of_the_course_in_months")
	private int courseDuration;

	@NonNull
//	@Min(value = 1, message = "Must be equal or greater than 1")
//	@Max(value = 10, message = "Must be equal or less than 10")
	@Column(name = "current_rating")
	private int currentRating;

	@NonNull
	@Size(max = 50)
	@Column(name = "status")
	private String status; // created/proposed/approved/finalized/after paying:inprogress/completed

	@NonNull
	@Column(name = "progress")
	private int progress; // user update percentage

	@NonNull
	@Size(max = 50)
	@Column(name = "start_date")
	private String startDate; // caluculate by its own (ongoing training table)

	@NonNull
	@Size(max = 50)
	@Column(name = "end_date")
	private String endDate;

	@NonNull
	@Size(max = 50)
	@Column(name = "maybe_start_time")
	private String maybeStartTime;

	@NonNull
	@Size(max = 50)
	@Column(name = "start_time")
	private String startTime;

	@NonNull
	@Size(max = 50)
	@Column(name = "end_time")
	private String endTime;

	@NonNull
	@Column(name = "expected_amount")
	private double expectedAmount;

	@Column(name = "amount_received")
	private double amountReceived; // Real amount received

	public Trainings() {
		super();
	}

	public Trainings(long id, long userId, long mentorId, long courseTechId, @Size(max = 50) String courseFacilities,
			int numOfAttendees, int courseDuration, int currentRating, @Size(max = 50) String status,
			@Size(max = 50) int progress, @Size(max = 50) String startDate, @Size(max = 50) String endDate,
			@Size(max = 50) String maybeStartTime, @Size(max = 50) String startTime, @Size(max = 50) String endTime,
			double expectedAmount, double amountReceived) {
		super();
		this.id = id;
		this.userId = userId;
		this.mentorId = mentorId;
		this.courseTechId = courseTechId;
		this.courseFacilities = courseFacilities;
		this.numOfAttendees = numOfAttendees;
		this.courseDuration = courseDuration;
		this.currentRating = currentRating;
		this.status = status;
		this.progress = progress;
		this.startDate = startDate;
		this.endDate = endDate;
		this.maybeStartTime = maybeStartTime;
		this.startTime = startTime;
		this.endTime = endTime;
		this.expectedAmount = expectedAmount;
		this.amountReceived = amountReceived;
	}

	public long getId() {
		return id;
	}

	public long getUserId() {
		return userId;
	}

	public long getMentorId() {
		return mentorId;
	}

	public long getCourseTechId() {
		return courseTechId;
	}

	public String getCourseFacilities() {
		return courseFacilities;
	}

	public int getNumOfAttendees() {
		return numOfAttendees;
	}

	public int getCourseDuration() {
		return courseDuration;
	}

	public int getCurrentRating() {
		return currentRating;
	}

	public String getStatus() {
		return status;
	}

	public int getProgress() {
		return progress;
	}

	public String getStartDate() {
		return startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public String getMaybeStartTime() {
		return maybeStartTime;
	}

	public String getStartTime() {
		return startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public double getExpectedAmount() {
		return expectedAmount;
	}

	public double getAmountReceived() {
		return amountReceived;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	public void setCourseTechId(long courseTechId) {
		this.courseTechId = courseTechId;
	}

	public void setCourseFacilities(String courseFacilities) {
		this.courseFacilities = courseFacilities;
	}

	public void setNumOfAttendees(int numOfAttendees) {
		this.numOfAttendees = numOfAttendees;
	}

	public void setCourseDuration(int courseDuration) {
		this.courseDuration = courseDuration;
	}

	public void setCurrentRating(int currentRating) {
		this.currentRating = currentRating;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setMaybeStartTime(String maybeStartTime) {
		this.maybeStartTime = maybeStartTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public void setExpectedAmount(double expectedAmount) {
		this.expectedAmount = expectedAmount;
	}

	public void setAmountReceived(double amountReceived) {
		this.amountReceived = amountReceived;
	}

	@Override
	public String toString() {
		return "Trainings [id=" + id + ", userId=" + userId + ", mentorId=" + mentorId + ", courseTechId="
				+ courseTechId + ", courseFacilities=" + courseFacilities + ", numOfAttendees=" + numOfAttendees
				+ ", courseDuration=" + courseDuration + ", currentRating=" + currentRating + ", status=" + status
				+ ", progress=" + progress + ", startDate=" + startDate + ", endDate=" + endDate + ", maybeStartTime="
				+ maybeStartTime + ", startTime=" + startTime + ", endTime=" + endTime + ", expectedAmount="
				+ expectedAmount + ", amountReceived=" + amountReceived + "]";
	}

}
