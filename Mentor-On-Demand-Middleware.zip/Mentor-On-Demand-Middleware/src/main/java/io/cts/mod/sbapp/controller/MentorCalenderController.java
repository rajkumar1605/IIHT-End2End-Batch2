package io.cts.mod.sbapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.mod.sbapp.bean.MentorCalender;
import io.cts.mod.sbapp.service.MentorCalenderService;

@CrossOrigin(origins = "http://localhost:4200") 
@RestController
@RequestMapping(path = "/mentorcalender")
public class MentorCalenderController {
	
		@Autowired
		private MentorCalenderService calenderService;

		@PostMapping(path="/insertcalender",headers="Accept=application/json")
		public void insertMentorCalender(@RequestBody MentorCalender mCalender) {
						
			MentorCalender mc=new MentorCalender();
			
			mc.setMentorId(mCalender.getMentorId());
			mc.setMentorCourseIds(mCalender.getMentorCourseIds());
			mc.setStartTime(mCalender.getStartTime());
			mc.setEndTime(mCalender.getEndTime());
			mc.setStartDate(mCalender.getStartDate());
			mc.setEndDate(mCalender.getEndDate());
			
			calenderService.insertMentorCalender(mc);
			

		}

		@GetMapping(path = "/getallmentorcalender")
		public List<MentorCalender> getAllMentorCalender() {
			return calenderService.getAllMentorCalender();
		}
		
		@GetMapping(path = "/getmentorcalenderbyid/{id}")
		public Optional<MentorCalender> getMentorCalenderById(@PathVariable long id) {
			return calenderService.findMentorCalenderById(id);
		}
		
		@PutMapping(path="/updatementorcalender/{id}")
		public ResponseEntity<MentorCalender> updateMentorCalenderDetails(@PathVariable("id") long id, @RequestBody MentorCalender mc) {
			calenderService.updateMentorCalenderDetails(id, mc);
			return new ResponseEntity<>(HttpStatus.OK);
			// return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		@DeleteMapping(path = "/deletementorcalender/{id}")
		public ResponseEntity<String> deleteMentorCalenderById(@PathVariable("id") long id) {
			
			/* delete all records of this mentor(add later) */

			calenderService.deleteMentorCalenderById(id);
			
			return new ResponseEntity<>("Mentor Calender details deleted!", HttpStatus.OK);

//			return new ResponseEntity<>("Mentor details are not deleted!", HttpStatus.NOT_FOUND);

	}


}
