package io.cts.mod.sbapp.model;

public class UserProposedTrainings {

	private String courseName;
	private String mentorName;
	private int duration;
	private double moneyToBePaid;

	public UserProposedTrainings() {
		super();
	}

	public UserProposedTrainings(String courseName, String mentorName, int duration, double moneyToBePaid) {
		super();
		this.courseName = courseName;
		this.mentorName = mentorName;
		this.duration = duration;
		this.moneyToBePaid = moneyToBePaid;
	}

	public String getCourseName() {
		return courseName;
	}

	public String getMentorName() {
		return mentorName;
	}

	public int getDuration() {
		return duration;
	}

	public double getMoneyToBePaid() {
		return moneyToBePaid;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void setMoneyToBePaid(double moneyToBePaid) {
		this.moneyToBePaid = moneyToBePaid;
	}

	@Override
	public String toString() {
		return "UserProposedTrainings [courseName=" + courseName + ", mentorName=" + mentorName + ", duration="
				+ duration + ", moneyToBePaid=" + moneyToBePaid + "]";
	}

}
