package io.cts.mod.sbapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cts.mod.sbapp.bean.MentorStatus;
import io.cts.mod.sbapp.bean.MentorWallet;

@Repository
public interface MentorWalletRepository extends CrudRepository<MentorWallet, Long> {


}

