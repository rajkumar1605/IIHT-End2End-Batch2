package io.cts.mod.sbapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cts.mod.sbapp.bean.MentorCalender;

@Repository
public interface MentorCalenderRepository extends CrudRepository<MentorCalender,Long>{

}
