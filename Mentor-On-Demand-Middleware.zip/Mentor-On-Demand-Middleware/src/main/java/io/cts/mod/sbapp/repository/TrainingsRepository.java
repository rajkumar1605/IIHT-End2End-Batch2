package io.cts.mod.sbapp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.cts.mod.sbapp.bean.Trainings;

@Repository
public interface TrainingsRepository extends CrudRepository<Trainings,Long>{
	
	@Query("Select t From Trainings t where t.status = :status and t.mentorId = :mentorid")
	List<Trainings> findByCreatedStatusAndMentorId(@Param("status") String status,@Param("mentorid") long mentorId);
	/* table name pojo class name */
	
	@Query("Select t From Trainings t where t.status = :status and t.mentorId = :mentorid and t.courseTechId = :coursetechid")
	Optional<Trainings> findByCreatedStatusAndMentorIdAndTrainingId(@Param("status") String status,@Param("mentorid") long mentorId,@Param("coursetechid") long courseTechId);
		
	@Query("Select t From Trainings t where t.status = :status and t.mentorId = :mentorid")
	List<Trainings> findByProposedStatusAndMentorId(@Param("status") String status,@Param("mentorid") long mentorId);
	
	@Query("Select t From Trainings t where t.status = :status and t.userId = :userid")
	List<Trainings> findByStatusAndUserId(@Param("status") String status,@Param("userid") long userId); 
	/* Used for 3 operations*/
	
	@Query("Select t From Trainings t where t.status = :status and t.courseTechId = :ctid and t.startTime = :starttime")
	List<Trainings> findByCreatedStatusAndTrainingIdAndStartTime(@Param("status") String status,@Param("ctid") long ctId,@Param("starttime") String startTime);
	
	@Query("Select t From Trainings t where t.status = :status and t.mentorId = :mentorid")
	List<Trainings> findByApprovedStatusAndMentorId(@Param("status") String status,@Param("mentorid") long mentorId);
	
	@Query("Select t From Trainings t where t.status = :status and t.mentorId = :mentorid")
	List<Trainings> findByFinalizedStatusAndMentorId(@Param("status") String status,@Param("mentorid") long mentorId);
	
	@Query("Select t From Trainings t where t.status = :status and t.mentorId = :mentorid")
	List<Trainings> findByInProgressStatusAndMentorId(@Param("status") String status,@Param("mentorid") long mentorId);
	
	@Query("Select t From Trainings t where t.status = :status and t.userId = :userid")
	List<Trainings> findByInprogressStatusAndUserId(@Param("status") String status,@Param("userid") long userId);
	
	@Query("Select t From Trainings t where t.status = :status and t.mentorId = :mentorid")
	List<Trainings> findByCompletedStatusAndMentorId(@Param("status") String status,@Param("mentorid") long mentorId);
	
	
//	@Query("Select c From Customer c where c.name = :name and c.age = :age")
//	Customer findByNameAndAge(@Param("name") String name, @Param("age") Integer age);
}
