package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.AllowableTechnology;
import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.bean.MentorStatus;
import io.cts.mod.sbapp.bean.PaymentsOfMentor;
import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.model.MentorPayment;
import io.cts.mod.sbapp.model.MentorCreatedTrainings;
import io.cts.mod.sbapp.model.MentorOngoingTrainings;
import io.cts.mod.sbapp.model.MentorTrainingsDelivered;
import io.cts.mod.sbapp.repository.MentorRepository;

@Service
public class MentorServiceImpl implements MentorService {

	@Autowired
	private MentorRepository repository;

	@Autowired
	private MentorStatusService mentorStatusService;

	@Autowired
	private TrainingsService trainingService;
	
	@Autowired
	private PaymentsOfMentorService paymentService;
	
	@Autowired
	private AllowableTechnologyService allowService;
	
	@Override
	public Mentor insertMentor(Mentor mentor) {

		MentorStatus ms = new MentorStatus();
		ms.setActive("Active");
		ms.setCourseId(0);
		ms.setNumSpecificTech(0);
		ms.setTotalTraining(0);
			
		MentorStatus msReturn = mentorStatusService.insertMentorStatus(ms);

		mentor.setMentorStatus(msReturn.getId());

		return repository.save(mentor);
	}

	@Override
	public List<Mentor> getAllMentors() {
		List<Mentor> mentors = new ArrayList<>();
		repository.findAll().forEach(mentors::add);
		return mentors;
	}

	@Override
	public Optional<Mentor> findMentorById(long id) {
		return repository.findById(id);
	}

	@Override
	public void updateMentorDetails(long id, Mentor mentor) {

		Optional<Mentor> mentorData = findMentorById(id);

		if (mentorData.isPresent()) {

			Mentor mtr = mentorData.get();
			String timeZone, workTiming, contactNumber, listOfSkills;
			int yoe;

			timeZone = mentor.getTimeZone();
			workTiming = mentor.getWorkTiming();
			contactNumber = mentor.getContactNumber();
			listOfSkills = mentor.getListOfSkills();
			yoe = mentor.getYearsOfExperience();

			if (timeZone != null) {
				mtr.setTimeZone(timeZone);
			} else {
				mtr.setTimeZone(mtr.getTimeZone());
			}
			if (workTiming != null) {
				mtr.setWorkTiming(timeZone);
			} else {
				mtr.setWorkTiming(mtr.getWorkTiming());
			}
			if (contactNumber != null) {
				mtr.setContactNumber(contactNumber);
			} else {
				mtr.setContactNumber(mtr.getContactNumber());
			}
			if (listOfSkills != null) {
				mtr.setListOfSkills(listOfSkills);
			} else {
				mtr.setListOfSkills(mtr.getListOfSkills());
			}
			if (yoe != 0) {
				mtr.setYearsOfExperience(yoe);
			} else {
				mtr.setYearsOfExperience(mtr.getYearsOfExperience());
			}

			mtr.setFirstName(mtr.getFirstName());
			mtr.setLastName(mtr.getLastName());
			mtr.setGender(mtr.getGender());
			mtr.setEducation(mtr.getEducation());
			mtr.setFacilities(mtr.getFacilities());
			mtr.setLinkedinURL(mtr.getLinkedinURL());
			mtr.setUserNameEmail(mtr.getUserNameEmail());
			mtr.setPassword(mtr.getPassword());
			mtr.setSecurityQuestion(mtr.getSecurityQuestion());
			mtr.setOwnSecurityQuestion(mtr.getOwnSecurityQuestion());
			mtr.setSecurityAnswer(mtr.getSecurityAnswer());
			mtr.setMentorStatus(mtr.getMentorStatus());

			repository.save(mtr);
		}
	}

	@Override
	public int deleteMentorById(long id) {
		/* delete all records of this mentor(add later) */
		int flag = 0;
		Optional<Mentor> currentMentor = findMentorById(id);

		if (currentMentor.isPresent()) {
			Mentor mentor = currentMentor.get();
			long mentorStatusId = mentor.getMentorStatus();

			if (mentorStatusService.deleteMenorStatusById(mentorStatusId)) {
				repository.deleteById(id);
				flag = 1;
			}
		}
		return flag;
	}
//	
	

	@Override
	public List<MentorCreatedTrainings> getCreatedTrainings(long mid) {
		
	List<MentorCreatedTrainings> traningsCreatedList = new ArrayList<MentorCreatedTrainings>();
		
		List<Trainings> trainings_list = trainingService.getByCreatedStatusAndMentorId("Created",mid);       /* insert mentor id on the runtime when getting from login */
		
		for(Trainings trainings:trainings_list) {
			MentorCreatedTrainings mcd=new MentorCreatedTrainings();
			
			mcd.setMentorId(trainings.getMentorId());
		 		    
			Optional<AllowableTechnology> allowableCourseData = allowService.findAllowableTechById(trainings.getCourseTechId());	
			
			if(allowableCourseData.isPresent()) {
				
				AllowableTechnology allowableCourse = allowableCourseData.get();
				mcd.setCourseName(allowableCourse.getTechName());
				
			}		    
		    mcd.setDurationOfCoures(trainings.getCourseDuration());
		    mcd.setAverageRating(trainings.getCurrentRating());   /* Here current rating holds the average rating of this course and mentor */
		    mcd.setExpectedPayment(trainings.getExpectedAmount());
		    
		    traningsCreatedList.add(mcd);		   
			
		}	
		
		return traningsCreatedList;
		
	}

	
	@Override
	public List<MentorOngoingTrainings> getCurrentTrainings(long mid) {
		
		List<MentorOngoingTrainings> traningsOngoingList = new ArrayList<MentorOngoingTrainings>();
		List<Trainings> trainings_list = trainingService.getByInprogressStatusAndMentorId("Inprogress",mid);       /* insert mentor id on the runtime when getting from login //Input=sign in mentorId */
		
		for(Trainings trainings:trainings_list) {
			MentorOngoingTrainings mog=new MentorOngoingTrainings();
			
			mog.setMentorId(trainings.getMentorId());
		
            Optional<AllowableTechnology> allowableCourseData = allowService.findAllowableTechById(trainings.getCourseTechId());	
			
			if(allowableCourseData.isPresent()) {
				
				AllowableTechnology allowableCourse = allowableCourseData.get();
				mog.setCourseName(allowableCourse.getTechName());
				
			}	
			
			Optional<Trainings> numOfAtt = trainingService.getByCreatedStatusAndMentorIdAndTrainingId("Created",mid,trainings.getCourseTechId());
		    mog.setNumOfAttendees(numOfAtt.get().getNumOfAttendees());
		    mog.setDurationOfCoures(trainings.getCourseDuration());
		    mog.setCurrentRating(trainings.getCurrentRating());
		    
		    Optional<PaymentsOfMentor> paymentRow = paymentService.getByTrainingIdForCurrentTrainings(trainings.getId());   /* current slot from payments of mentors table // Input = training Id from trainings_table*/
		    
		    mog.setCurrentSlot(paymentRow.get().getCurrentSlot());            
		    
		    mog.setTotalPayment(20000);  /* Take it from payments table after deducting commision*/
		    
		    traningsOngoingList.add(mog);		   
			
		}	
		
		return traningsOngoingList;
		
	}
	
	@Override
	public List<MentorTrainingsDelivered> getCompletedTrainings(long mid) {

		List<MentorTrainingsDelivered> traningsDeliveredList = new ArrayList<MentorTrainingsDelivered>();
		
		List<Trainings> trainings_list = trainingService.getByCompletedStatusAndMentorId("Completed",mid);       /* insert mentor id on the runtime when getting from login */
		
		for(Trainings trainings:trainings_list) {
			MentorTrainingsDelivered mtd=new MentorTrainingsDelivered();
			
			mtd.setMentorId(trainings.getMentorId());
		 		    
			Optional<AllowableTechnology> allowableCourseData = allowService.findAllowableTechById(trainings.getCourseTechId());	
			
			if(allowableCourseData.isPresent()) {
				
				AllowableTechnology allowableCourse = allowableCourseData.get();
				mtd.setCourseName(allowableCourse.getTechName());
				
			}		    
		    mtd.setDateOfCompletion(trainings.getEndDate());
		    mtd.setEarning(trainings.getAmountReceived());
		    mtd.setRating(trainings.getCurrentRating());
		    mtd.setStatusOfPayment("paid");  /* Take it from payments table */
		    
		    traningsDeliveredList.add(mtd);		   
			
		}	
		
		return traningsDeliveredList;
	}




	@Override
	public List<MentorPayment> getMentorPayment(long mid) {
		
		List<MentorPayment> paymentList = new ArrayList<MentorPayment>();
		List<PaymentsOfMentor> payments_list = paymentService.getMentorPayment(mid);       /* insert mentor id on the runtime when getting from login //Input=sign in mentorId  */
				
		
		for(PaymentsOfMentor payment:payments_list) {
			MentorPayment p=new MentorPayment();
			
			p.setMentorId(payment.getMentorId());
		    p.setTrainingsId(payment.getTrainingId());
		    p.setCurrentSlot(payment.getCurrentSlot());  
		    
		    Optional<Trainings> courseData=null;
		    courseData = trainingService.findTrainings(payment.getTrainingId());
		    if(courseData.isPresent()) {
		    	Trainings courseDetails = courseData.get();

		    	Optional<AllowableTechnology> allowableCourseData = allowService.findAllowableTechById(courseDetails.getCourseTechId());	
					
					if(allowableCourseData.isPresent()) {
						
						AllowableTechnology allowableCourse = allowableCourseData.get();
						p.setCourseName(allowableCourse.getTechName());
						
				}
			    p.setDuration(courseDetails.getCourseDuration());  
			    p.setStatus(courseDetails.getStatus());
			    p.setExpectedRemainingAmount(00);   /* Have to calculate */
			    
			    paymentList.add(p);		
			    
		    }else {
		    	return null;
		    }    	
		}
		return paymentList;	

	}

}
