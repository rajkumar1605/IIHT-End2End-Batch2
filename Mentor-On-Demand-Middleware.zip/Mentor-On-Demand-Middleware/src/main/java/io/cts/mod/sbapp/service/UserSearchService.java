package io.cts.mod.sbapp.service;

import java.util.List;

import io.cts.mod.sbapp.model.UserSearchResult;

public interface UserSearchService {
	
	public List<UserSearchResult> getUserSearchResult(String timeValue, String courseName);

}
