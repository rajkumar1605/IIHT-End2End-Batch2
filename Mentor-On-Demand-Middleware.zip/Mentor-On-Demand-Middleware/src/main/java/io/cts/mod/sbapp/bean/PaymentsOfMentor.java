package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "payments_of_mentor")
public class PaymentsOfMentor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Column(name = "mentor_id")
	private long mentorId;

	@NonNull
	@Column(name = "training_id")
	private long trainingId;

	@NonNull
	@Column(name = "current_slot")
	private int currentSlot;

	@NonNull
	@Size(max = 50)
	@Column(name = "txn_type")
	private String txnType;

	@NonNull
	@Size(max = 50)
	@Column(name = "datetime")
	private String dateTime;

	@NonNull
	@Size(max = 50)
	@Column(name = "payment_status")
	private String paymentStatus;

	@NonNull
	@Column(name = "amount")
	private double amountOfThisTraining;

	public PaymentsOfMentor() {
		super();

	}

	public PaymentsOfMentor(long id, long mentorId, long trainingId, int currentSlot, @Size(max = 50) String txnType,
			@Size(max = 50) String dateTime, @Size(max = 50) String paymentStatus, double amountOfThisTraining) {
		super();
		this.id = id;
		this.mentorId = mentorId;
		this.trainingId = trainingId;
		this.currentSlot = currentSlot;
		this.txnType = txnType;
		this.dateTime = dateTime;
		this.paymentStatus = paymentStatus;
		this.amountOfThisTraining = amountOfThisTraining;
	}

	public long getId() {
		return id;
	}

	public long getMentorId() {
		return mentorId;
	}

	public long getTrainingId() {
		return trainingId;
	}

	public int getCurrentSlot() {
		return currentSlot;
	}

	public String getTxnType() {
		return txnType;
	}

	public String getDateTime() {
		return dateTime;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public double getAmountOfThisTraining() {
		return amountOfThisTraining;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	public void setTrainingId(long trainingId) {
		this.trainingId = trainingId;
	}

	public void setCurrentSlot(int currentSlot) {
		this.currentSlot = currentSlot;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public void setAmountOfThisTraining(double amountOfThisTraining) {
		this.amountOfThisTraining = amountOfThisTraining;
	}

	@Override
	public String toString() {
		return "PaymentsOfMentor [id=" + id + ", mentorId=" + mentorId + ", trainingId=" + trainingId + ", currentSlot="
				+ currentSlot + ", txnType=" + txnType + ", dateTime=" + dateTime + ", paymentStatus=" + paymentStatus
				+ ", amountOfThisTraining=" + amountOfThisTraining + "]";
	}

}
