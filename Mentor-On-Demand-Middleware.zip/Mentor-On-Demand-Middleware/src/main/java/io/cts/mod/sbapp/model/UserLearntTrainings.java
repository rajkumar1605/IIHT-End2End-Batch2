package io.cts.mod.sbapp.model;

public class UserLearntTrainings {

	private String courseName;
	private String mentorName;
	private int duration;
	private String dateOfCompletion;
	private double moneyPaid;

	public UserLearntTrainings() {
		super();
	}

	public UserLearntTrainings(String courseName, String mentorName, int duration, String dateOfCompletion,
			double moneyPaid) {
		super();
		this.courseName = courseName;
		this.mentorName = mentorName;
		this.duration = duration;
		this.dateOfCompletion = dateOfCompletion;
		this.moneyPaid = moneyPaid;
	}

	public String getCourseName() {
		return courseName;
	}

	public String getMentorName() {
		return mentorName;
	}

	public int getDuration() {
		return duration;
	}

	public String getDateOfCompletion() {
		return dateOfCompletion;
	}

	public double getMoneyPaid() {
		return moneyPaid;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void setDateOfCompletion(String dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}

	public void setMoneyPaid(double moneyPaid) {
		this.moneyPaid = moneyPaid;
	}

	@Override
	public String toString() {
		return "UserLearntTrainings [courseName=" + courseName + ", mentorName=" + mentorName + ", duration=" + duration
				+ ", dateOfCompletion=" + dateOfCompletion + ", moneyPaid=" + moneyPaid + "]";
	}

}
