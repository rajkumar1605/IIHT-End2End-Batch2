package io.cts.mod.sbapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.mod.sbapp.model.UserSearchResult;
import io.cts.mod.sbapp.service.UserSearchService;

@CrossOrigin(origins = "http://localhost:4200") 
@RestController
@RequestMapping(path = "/usersearch")
public class UserSearchController {
	
	@Autowired
	private UserSearchService searchService;
	
	@GetMapping(path="result/{timeValue}/{courseName}", headers = "Accept=application/json")
	public List<UserSearchResult> getUserSearchResult(@PathVariable("timeValue")String timeValue,@PathVariable("courseName")String courseName){
		
		return searchService.getUserSearchResult(timeValue, courseName);
		
	}

}
