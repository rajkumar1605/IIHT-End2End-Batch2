package io.cts.mod.sbapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.bean.MentorWallet;

import io.cts.mod.sbapp.model.MentorPayment;
import io.cts.mod.sbapp.model.MentorCreatedTrainings;
import io.cts.mod.sbapp.model.MentorOngoingTrainings;
import io.cts.mod.sbapp.model.MentorTrainingsDelivered;
import io.cts.mod.sbapp.service.MentorService;
import io.cts.mod.sbapp.service.MentorWalletService;

@CrossOrigin(origins = "http://localhost:4200") 
@RestController
@RequestMapping(path = "/mentor")
public class MentorController {
	
	public static long createdMentorId=0;

	@Autowired
	private MentorService mentorDetailsService;
	
	@Autowired
	private MentorWalletService mentorWalletService;

	@PostMapping(path = "/insertmentor", headers = "Accept=application/json") /*To insert data into the db from signup*/
	public void insertMentor(@RequestBody Mentor mentor) {

		Mentor mt = new Mentor();

		// mt.setId(mentor.getId()); //Auto Incremented Id
		mt.setFirstName(mentor.getFirstName());
		mt.setLastName(mentor.getLastName());
		mt.setGender(mentor.getGender());
		mt.setEducation(mentor.getEducation());
		mt.setTimeZone(mentor.getTimeZone());
		mt.setWorkTiming(mentor.getWorkTiming());
		mt.setListOfSkills(mentor.getListOfSkills());
		mt.setFacilities(mentor.getFacilities());
		mt.setYearsOfExperience(mentor.getYearsOfExperience());
		mt.setLinkedinURL(mentor.getLinkedinURL());
		mt.setContactNumber(mentor.getContactNumber());
		mt.setUserNameEmail(mentor.getUserNameEmail());
		mt.setPassword(mentor.getPassword());

		mt.setSecurityQuestion(mentor.getSecurityQuestion());
		mt.setOwnSecurityQuestion(mentor.getOwnSecurityQuestion());
		mt.setSecurityAnswer(mentor.getSecurityAnswer());

		Mentor createdMentor = mentorDetailsService.insertMentor(mt);
		
	    createdMentorId=createdMentor.getId();
	    
	    MentorWallet mw=new MentorWallet();
		mw.setMentorId(createdMentorId);
		mw.setWallet(0);
		mw.setWithdrawnMoney(0);
		mentorWalletService.insertMentorWallet(mw);
		
//	    System.out.println(createdMentorId);
	    
	   
	}
	
	@PostMapping(path = "/emailpasswordsignin")
	public Object mentorSignin() {
		return null;	
	}
	
	@GetMapping(path = "/getallmentors")
	public List<Mentor> getAllMentors() {
		return mentorDetailsService.getAllMentors();
	}

	@GetMapping(path = "/getmentorsbyid/{id}")
	public Optional<Mentor> getMentorById(@PathVariable long id) {
		return mentorDetailsService.findMentorById(id);
	}
	
	
	@GetMapping(path="getcreatedtrainings/{mid}")
	public List<MentorCreatedTrainings> getCreatedTrainings(@PathVariable("mid") long id){
		return mentorDetailsService.getCreatedTrainings(id);	
	}
	
	@GetMapping(path="getcurrenttrainings/{mid}")
	public List<MentorOngoingTrainings> getCurrentTrainings(@PathVariable("mid") long id){
		return mentorDetailsService.getCurrentTrainings(id);	
	}
	
	@GetMapping(path="getcompletedtrainings/{mid}")
	public List<MentorTrainingsDelivered> getCompletedTrainings(@PathVariable("mid") long id){
		return mentorDetailsService.getCompletedTrainings(id);	
	}
	
	@GetMapping(path="getmentorpaymentdetails/{mid}")
	public List<MentorPayment> getMentorPaymentDetails(@PathVariable("mid") long id){
		return mentorDetailsService.getMentorPayment(id);	
	}
	

	@PutMapping(path = "/updatementor/{id}")
	public ResponseEntity<Mentor> updateMentorDetails(@PathVariable("id") long id, @RequestBody Mentor mentor) {
		mentorDetailsService.updateMentorDetails(id, mentor);
		return new ResponseEntity<>(HttpStatus.OK);
		// return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@DeleteMapping(path = "/deletementor/{id}")
	public ResponseEntity<String> deleteAMentor(@PathVariable("id") long id) {
		
		if (mentorDetailsService.deleteMentorById(id) == 1) {
			return new ResponseEntity<>("Mentor details deleted!", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Mentor details are not deleted!", HttpStatus.NOT_FOUND);
		}
	}

}
