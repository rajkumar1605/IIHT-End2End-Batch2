package io.cts.mod.sbapp.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.AllowableTechnology;
import io.cts.mod.sbapp.bean.Trainings;

import io.cts.mod.sbapp.repository.TrainingsRepository;

@Service
public class TrainingsServiceImpl implements TrainingsService {

	@Autowired
	private TrainingsRepository repository;
	
	@Autowired
	private AllowableTechnologyService allowService;
	
    public static int randBetween(int start, int end) {
        return start + (int)Math.round(Math.random() * (end - start));
    }

	@Override
	public Trainings insertTrainings(Trainings train) {
		
		if(train.getStatus()!=null) {
			train.setStatus(train.getStatus());
		}else {
			train.setStatus("Created");
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

			Calendar cal = Calendar.getInstance();
			
			int dt = cal.get(Calendar.DATE);
			int date = randBetween(dt, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			cal.set(Calendar.DATE, date);
/*		    int month = cal.get(Calendar.MONTH); 
		    int year = cal.get(Calendar.YEAR); */
   
		  	train.setStartDate( sdf.format(cal.getTime()) );

		    cal.add(Calendar.MONTH, train.getCourseDuration());
		    			
			train.setEndDate(sdf.format(cal.getTime()));
			
		    String[] stTime={"9:00 AM", "1:00 PM", "5:00 PM", "9:00 PM"};
		    String[] edTime={"12:00 NOON", "4:00 PM", "8:00 PM", "12:00 MIDNIGHT"};
		   
			Random rand = new Random(); 
		    int randomNum = rand.nextInt(stTime.length); 
		    train.setStartTime(stTime[randomNum]); 
		    train.setEndTime(edTime[randomNum]);
		}
		if(train.getProgress()!=0) {
			train.setProgress(train.getProgress());
		}else {
			train.setProgress(0);
		}
		
		Optional<AllowableTechnology> allowableCourseData = allowService.findAllowableTechById(train.getCourseTechId());	
		
		if(allowableCourseData.isPresent()) {
			
			AllowableTechnology allowableCourse = allowableCourseData.get();
			train.setCourseTechId(allowableCourse.getId());
			return repository.save(train);		
		}else {
			return null;
		}
		
	}
	
	@Override
	public Trainings insertFromUser(Trainings train) {
		return repository.save(train);
	}

	@Override
	public List<Trainings> getAllTrainings() {
		List<Trainings> train = new ArrayList<>();
		repository.findAll().forEach(train::add);
		return train;
	}

	@Override
	public Optional<Trainings> findTrainings(long id) {
		return repository.findById(id);
	}

	@Override
	public void updateTrainingsDetails(long id, Trainings train) {
		/* cannot update course name */
		
		Optional<Trainings> trainingData = findTrainings(id);
		
		if(trainingData.isPresent()) {
			Trainings tr=trainingData.get();
			long userId, mentorId;
			double expectedAmount, amountReceived;
			int courseDuration,numOfAttendees, currentRating, progress;
			String courseFacilities, status,startDate, endDate,
					maybeStartTime, startTime,endTime;
			
			userId=train.getUserId();
			mentorId=train.getMentorId();
			
			expectedAmount=train.getExpectedAmount();
			amountReceived=train.getAmountReceived();
			
			numOfAttendees=train.getNumOfAttendees();
			currentRating=train.getCurrentRating();
		
			courseFacilities=train.getCourseFacilities();
			courseDuration=train.getCourseDuration();
			status=train.getStatus();
			progress=train.getProgress();
			startDate=train.getStartDate();
			endDate=train.getEndDate();
			maybeStartTime=train.getMaybeStartTime();
			startTime=train.getStartTime();
			endTime=train.getEndTime();
				
			if (userId != 0) {
				tr.setUserId(userId);
			} else {
				tr.setUserId(tr.getUserId());
			}
			if (mentorId != 0) {
				tr.setMentorId(mentorId);
			} else {
				tr.setMentorId(tr.getMentorId());
			}
			if (expectedAmount != 0) {
				tr.setExpectedAmount(expectedAmount);
			} else {
				tr.setExpectedAmount(tr.getExpectedAmount());
			}
			if (amountReceived != 0) {
				tr.setAmountReceived(amountReceived);
			} else {
				tr.setAmountReceived(tr.getAmountReceived());
			}
			
			if(numOfAttendees!=0) {
				tr.setNumOfAttendees(numOfAttendees);
			}else {
				tr.setNumOfAttendees(tr.getNumOfAttendees());
			}
			if(currentRating!=0) {
				tr.setCurrentRating(currentRating);
			}
			else {
				tr.setCurrentRating(tr.getCurrentRating());
			}
			if(courseFacilities!=null) {
				tr.setCourseFacilities(courseFacilities);
			}else {
				tr.setCourseFacilities(tr.getCourseFacilities());
			}
			if(courseDuration!=0) {
				tr.setCourseDuration(courseDuration);
			}else {
				tr.setCourseDuration(tr.getCourseDuration());
			}
			if(status!=null) {
				tr.setStatus(status);
			}else {
				tr.setStatus(tr.getStatus());
			}
			if(progress!=0) {
				tr.setProgress(progress);
			}else {
				tr.setProgress(tr.getProgress());
			}
			if(startDate!=null) {
				tr.setStartDate(startDate);
			}else {
				tr.setStartDate(tr.getStartDate());
			}
			if(endDate!=null) {
				tr.setEndDate(endDate);
			}else {
				tr.setEndDate(tr.getEndDate());
			}
			if(maybeStartTime!=null) {
				tr.setMaybeStartTime(maybeStartTime);
			}else {
				tr.setMaybeStartTime(tr.getMaybeStartTime());
			}
			if(startTime!=null) {
				tr.setStartTime(startTime);
			}else {
				tr.setStartTime(tr.getStartTime());
			}
			if(endTime!=null) {
				tr.setEndTime(endTime);
			}else {
				tr.setEndTime(tr.getEndTime());
			}

			repository.save(tr);
		}
		
	}

	@Override
	public boolean deleteTrainings(long id) {
		repository.deleteById(id);
		Optional<Trainings> trs=findTrainings(id);
		if(trs.isPresent()) {
			return false;
		}
		else {
			return true;
		}
	}
	
	@Override
	public Optional<Trainings> getByCreatedStatusAndMentorIdAndTrainingId(String status, long mid,long cid) {
		return repository.findByCreatedStatusAndMentorIdAndTrainingId(status,mid,cid);
	}
	
	@Override
	public List<Trainings> getByCreatedStatusAndMentorId(String status, long mid) {
		return repository. findByCreatedStatusAndMentorId(status, mid);
	}
	
	@Override
	public List<Trainings> getByInprogressStatusAndMentorId(String status, long mid) {
		return repository.findByInProgressStatusAndMentorId(status,mid);
	}
	
	@Override
	public List<Trainings> getByCompletedStatusAndMentorId(String status, long mid) {
		return repository.findByCompletedStatusAndMentorId(status,mid);
	}

	@Override
	public List<Trainings> getByInprogressStatusAndUserId(String status, long uid) {	
		return repository.findByInprogressStatusAndUserId(status,uid);
	}

	@Override
	public List<Trainings> getByStatusAndUserId(String status, long uid) {
	     return repository.findByStatusAndUserId(status,uid);
	 }

	@Override
	public List<Trainings> getByCreatedStatusAndTrainingIdAndStartTime(String status, long ctId,String startTime) {
		return repository.findByCreatedStatusAndTrainingIdAndStartTime(status,ctId,startTime);
	}


}
