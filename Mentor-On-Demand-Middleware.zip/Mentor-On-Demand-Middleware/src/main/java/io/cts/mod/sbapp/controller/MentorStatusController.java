package io.cts.mod.sbapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.bean.MentorStatus;
import io.cts.mod.sbapp.service.MentorStatusService;

@CrossOrigin(origins = "http://localhost:4200") 
@RestController
@RequestMapping(path = "/mentorstatus") 
public class MentorStatusController {

	@Autowired
	private MentorStatusService mentorStausService;

	public boolean deleteMentorStatus(long id) {
		return mentorStausService.deleteMenorStatusById(id);
	}
	
	@PostMapping(path="/insertmentorstatus",headers="Accept=application/json")
	public void insertMentorStatus(@RequestBody MentorStatus mtrsts) {
					
		MentorStatus ms = new MentorStatus();
		ms.setActive(mtrsts.getActive());
		ms.setCourseId(mtrsts.getCourseId());
		ms.setNumSpecificTech(mtrsts.getNumSpecificTech());
		ms.setTotalTraining(mtrsts.getTotalTraining());
		
		mentorStausService.insertMentorStatus(ms);	

	}
	
	@GetMapping(path = "/getallmentorstatus")
	public List<MentorStatus> getAllMentorsStatus() {
		return mentorStausService.getAllMentorsStatus();
	}

	@GetMapping(path = "/getmentorstatusbyid/{id}")
	public Optional<MentorStatus> getMentorsStatusById(@PathVariable long id) {
		return mentorStausService.findMentorStatusById(id);
	}

	@PutMapping("/updatementorstatus/{id}")
	public ResponseEntity<Mentor> updateMentorStatus(@PathVariable("id") long id, @RequestBody MentorStatus mtrSt) {
		mentorStausService.updateMentorStatus(id, mtrSt);
		return new ResponseEntity<>(HttpStatus.OK);
		// return new ResponseEntity<>(HttpStatus.NOT_FOUND);

	}

	@DeleteMapping(path = "/deletementorstatus/{id}")
	public ResponseEntity<String> deleteAMentorStatusById(@PathVariable("id") long id) {
		/* delete all records of this mentor(add later) */

		mentorStausService.deleteMenorStatusById(id);

		return new ResponseEntity<>("Mentor details deleted!", HttpStatus.OK);

//		return new ResponseEntity<>("Mentor details are not deleted!", HttpStatus.NOT_FOUND);

	}

}
