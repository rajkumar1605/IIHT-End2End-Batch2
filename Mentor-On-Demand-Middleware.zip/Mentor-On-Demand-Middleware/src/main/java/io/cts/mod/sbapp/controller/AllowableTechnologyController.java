package io.cts.mod.sbapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.mod.sbapp.bean.AllowableTechnology;
import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.service.AllowableTechnologyService;

@CrossOrigin(origins = "http://localhost:4200") 
@RestController
@RequestMapping(path = "/allowable")
public class AllowableTechnologyController {

	@Autowired
	private AllowableTechnologyService allowService;

	@PostMapping(path="/tech",headers="Accept=application/json")
	public void insertAllowableTech(@RequestBody AllowableTechnology tech) {
		
//		System.out.println("Inserting technology : "+tech);
		
		AllowableTechnology ty=new AllowableTechnology();
		
//		ty.setId(tech.getId());  //Auto Incremented Id
		ty.setTechName(tech.getTechName());
		ty.setMinDuration(tech.getMinDuration());
		ty.setMaxDuration(tech.getMaxDuration());
		
		allowService.insertAllowableTechnology(ty);
		
//    	{
//      "techName":"Java","maxDuration":"4 months","minDuration":"4 hours"
//  	}
	}

	@GetMapping(path = "/getallallowable")
	public List<AllowableTechnology> getAllAllowable() {
		return allowService.getAllAllowableTechnology();
	}
	
	@GetMapping(path = "/getallowablebyid/{id}")
	public Optional<AllowableTechnology> getAllowableTechById(@PathVariable long id) {
		return allowService.findAllowableTechById(id);
	}
	
	@PutMapping(path="/updateallowable/{id}")
	public ResponseEntity<AllowableTechnology> updateAllowableTechDetails(@PathVariable("id") long id, @RequestBody AllowableTechnology tech) {
		allowService.updateAllowableTechnologyDetails(id, tech);
		return new ResponseEntity<>(HttpStatus.OK);
		// return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping(path = "/deleteallowable/{id}")
	public ResponseEntity<String> deleteAllowableById(@PathVariable("id") long id) {
		
		/* delete all records of this mentor(add later) */

		allowService.deleteAllowableTechById(id);

		return new ResponseEntity<>("Allowable Technology details deleted!", HttpStatus.OK);

//		return new ResponseEntity<>("Mentor details are not deleted!", HttpStatus.NOT_FOUND);

	}

}
