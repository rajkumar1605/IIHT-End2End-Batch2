package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.model.MentorPayment;
import io.cts.mod.sbapp.model.MentorCreatedTrainings;
import io.cts.mod.sbapp.model.MentorOngoingTrainings;
import io.cts.mod.sbapp.model.MentorTrainingsDelivered;

public interface MentorService {
	
	public Mentor insertMentor(Mentor mentor);
	public List<Mentor> getAllMentors();
	public Optional<Mentor> findMentorById(long id);
	public void updateMentorDetails(long id,Mentor mentor);
	public int deleteMentorById(long id);
	
	public List<MentorCreatedTrainings> getCreatedTrainings(long mid);
	public List<MentorOngoingTrainings> getCurrentTrainings(long mid);
	public List<MentorTrainingsDelivered> getCompletedTrainings(long mid);
	
	public List<MentorPayment> getMentorPayment(long mid);	
}

