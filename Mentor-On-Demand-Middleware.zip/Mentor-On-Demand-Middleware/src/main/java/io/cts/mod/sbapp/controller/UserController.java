package io.cts.mod.sbapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.bean.User;
import io.cts.mod.sbapp.bean.UserPayments;
import io.cts.mod.sbapp.model.UserConfirmedTrainings;
import io.cts.mod.sbapp.model.UserLearntTrainings;
import io.cts.mod.sbapp.model.UserOngoingTrainings;
import io.cts.mod.sbapp.model.UserProposedTrainings;
import io.cts.mod.sbapp.service.UserService;


@CrossOrigin(origins = "http://localhost:4200") 
@RestController
@RequestMapping(path = "/user")
public class UserController {
		
		public static long createdUserId=0;

		@Autowired
		private UserService userDetailsService;

		@PostMapping(path = "/insertuser", headers = "Accept=application/json") /*To insert data into the db from signup*/
		public void insertUser(@RequestBody User user) {

			User us = new User();

			// mt.setId(mentor.getId()); //Auto Incremented Id
			us.setFirstName(user.getFirstName());
			us.setLastName(user.getLastName());
			us.setGender(user.getGender());
			us.setEducation(user.getEducation());
			us.setAreaOfInterest(user.getAreaOfInterest());
			us.setContactNumber(user.getContactNumber());
			us.setEmailId(user.getEmailId());
			us.setPassword(user.getPassword());

			us.setSecurityQuestion(user.getSecurityQuestion());
			us.setOwnSecurityQuestion(user.getOwnSecurityQuestion());
			us.setSecurityAnswer(user.getSecurityAnswer());
			
			us.setActive("Active");

			User createdUser = userDetailsService.insertUser(us);
			
		    createdUserId=createdUser.getId();
//		    System.out.println(createdMentorId);
		    
		   
		}
		
		@PostMapping(path = "/emailpasswordsignin")
		public Object userSignin() {
			return null;	
		}
		
		@PostMapping(path="createtraining/{uid}/{mid}/{cid}")  /* user id after signin */
		public void createTraining(@PathVariable("uid") long uid,@PathVariable("mid") long mid,@PathVariable("cid")long cid) {
			userDetailsService.createTraining(uid,mid,cid); 	
		}
		
		@GetMapping(path = "/getallusers")
		public List<User> getAllUsers() {
			return userDetailsService.getAllUsers();
		}

		@GetMapping(path = "/getusersbyid/{id}")
		public Optional<User> getUserById(@PathVariable long id) {
			return userDetailsService.findUserById(id);
		}
		
		
		@GetMapping(path="getcurrenttrainings/{uid}")
		public List<UserOngoingTrainings> getCurrentTrainings(@PathVariable("uid") long id){
			return userDetailsService.getCurrentTrainings(id);	
		}
		
		@GetMapping(path="getconfirmedtrainings/{uid}")
		public List<UserConfirmedTrainings> getConfirmedTrainings(@PathVariable("uid") long id){
			return userDetailsService.getConfirmedTrainings(id);	
		}
		
		@GetMapping(path="getproposedtrainings/{uid}")
		public List<UserProposedTrainings> getProposedTrainings(@PathVariable("uid") long id){
			return userDetailsService.getProposedTrainings(id);	
		}
		
		@GetMapping(path="getcompletedtrainings/{uid}")
		public List<UserLearntTrainings> getCompletedTrainings(@PathVariable("uid") long id){
			return userDetailsService.getCompletedTrainings(id);	
		}
		
		@GetMapping(path="getuserpaymentdetails")
		public List<UserPayments> getUserPaymentDetails(){
			return userDetailsService.getUserPayment();	
		}
		

		@PutMapping(path = "/updateuser/{id}")
		public ResponseEntity<User> updateUserDetails(@PathVariable("id") long id, @RequestBody User user) {
			userDetailsService.updateUserDetails(id, user);
			return new ResponseEntity<>(HttpStatus.OK);
			// return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		@PutMapping(path = "/updateprogressbyuser/{tid}/{mid}/{uid}")
		public ResponseEntity<User> updateProgressByUser(@PathVariable("tid") long tid, @RequestBody Trainings train) /* progress */{
			userDetailsService.updateProgress(tid,train);
			return new ResponseEntity<>(HttpStatus.OK);
			// return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		@DeleteMapping(path = "/deleteuser/{id}")
		public ResponseEntity<String> deleteAUser(@PathVariable("id") long id) {
			
			if (userDetailsService.deleteUserById(id) == 1) {
				return new ResponseEntity<>("Mentor details deleted!", HttpStatus.OK);
			} else {
				return new ResponseEntity<>("Mentor details are not deleted!", HttpStatus.NOT_FOUND);
			}
	}

}