package io.cts.mod.sbapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.bean.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
	
//	List<Mentor> findById(long id);
	
//	@Query("Select c From Customer c where c.name = :name and c.age = :age")
//	Customer findByNameAndAge(@Param("name") String name, @Param("age") Integer age);

}


