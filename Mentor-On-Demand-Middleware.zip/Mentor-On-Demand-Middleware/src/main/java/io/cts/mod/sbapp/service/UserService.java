package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.bean.User;
import io.cts.mod.sbapp.bean.UserPayments;
import io.cts.mod.sbapp.model.UserConfirmedTrainings;
import io.cts.mod.sbapp.model.UserLearntTrainings;
import io.cts.mod.sbapp.model.UserOngoingTrainings;
import io.cts.mod.sbapp.model.UserProposedTrainings;



public interface UserService {
	
	public User insertUser(User user);
	public List<User> getAllUsers();
	public Optional<User> findUserById(long id);
	public void updateUserDetails(long id,User user);
	public int deleteUserById(long id);
	
	public List<UserOngoingTrainings> getCurrentTrainings(long uid);

	public List<UserConfirmedTrainings> getConfirmedTrainings(long uid);
	public List<UserProposedTrainings> getProposedTrainings(long uid);
	
	public List<UserLearntTrainings> getCompletedTrainings(long uid);
	
	public List<UserPayments> getUserPayment();	
	
	public void createTraining(long uid,long mid,long cid);
	public void updateProgress(long tid, Trainings train); 
	
	public List<Trainings> getAllDataOfSpecificCourse(long ctId,long mid);


}
