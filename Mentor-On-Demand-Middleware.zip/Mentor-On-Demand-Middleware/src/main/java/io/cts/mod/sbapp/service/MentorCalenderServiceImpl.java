package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.AllowableTechnology;
import io.cts.mod.sbapp.bean.MentorCalender;
import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.repository.MentorCalenderRepository;

@Service
public class MentorCalenderServiceImpl implements MentorCalenderService {

	@Autowired
	private MentorCalenderRepository repository;

	@Override
	public MentorCalender insertMentorCalender(MentorCalender mc) {
		return repository.save(mc);
	}

	@Override
	public List<MentorCalender> getAllMentorCalender() {
		List<MentorCalender> mentorCalender = new ArrayList<>();
		repository.findAll().forEach(mentorCalender::add);
		return mentorCalender;
	}

	@Override
	public Optional<MentorCalender> findMentorCalenderById(long id) {
		return repository.findById(id);
	}

	@Override
	public void updateMentorCalenderDetails(long id, MentorCalender mc) {

		Optional<MentorCalender> calenderData = findMentorCalenderById(id);

		if (calenderData.isPresent()) {
			MentorCalender mcd = calenderData.get();
			long mId, mCId;
			String startTime, endTime, startDate, endDate;

			mId = mc.getMentorId();
			mCId = mc.getMentorCourseIds();
			startTime = mc.getStartTime();
			endTime = mc.getEndTime();
			startDate = mc.getStartDate();
			endDate = mc.getEndDate();

			if (mId != 0) {
				mcd.setMentorId(mId);
			} else {
				mcd.setMentorId(mcd.getMentorId());
			}
			if (mCId != 0) {
				mcd.setMentorCourseIds(mCId);
			} else {
				mcd.setMentorCourseIds(mcd.getMentorCourseIds());
			}
			if (startTime != null) {
				mcd.setStartTime(startTime);
			} else {
				mcd.setStartTime(mcd.getStartTime());
			}
			if (endTime != null) {
				mcd.setEndTime(endTime);
			} else {
				mcd.setEndTime(mcd.getEndTime());
			}
			if (startDate != null) {
				mcd.setStartDate(startDate);
			} else {
				mcd.setStartDate(mcd.getStartDate());
			}
			if (endDate != null) {
				mcd.setEndDate(endDate);
			} else {
				mcd.setEndDate(mcd.getEndDate());
			}
			repository.save(mcd);
		}
	}

	@Override
	public boolean deleteMentorCalenderById(long id) {
		repository.deleteById(id);
		Optional<MentorCalender> mcbid = findMentorCalenderById(id);
		if(mcbid.isPresent()) {
			return false;
		}
		else {
			return true;
		}
	}

}
