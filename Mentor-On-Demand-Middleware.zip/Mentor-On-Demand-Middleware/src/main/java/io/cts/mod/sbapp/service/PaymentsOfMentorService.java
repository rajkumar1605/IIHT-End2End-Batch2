package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.PaymentsOfMentor;

public interface PaymentsOfMentorService {
	
	public PaymentsOfMentor insertPaymentsOfMentor(PaymentsOfMentor pay);
	public List<PaymentsOfMentor> getAllPaymentsOfMentor();
	public Optional<PaymentsOfMentor> findPaymentsOfMentorById(long id);
	public void updatePaymentsOfMentorDetails(long id,PaymentsOfMentor pay);
	public boolean deletePaymentsOfMentorById(long id);	
	
	public List<PaymentsOfMentor> getMentorPayment(long id);
	public Optional<PaymentsOfMentor> getByTrainingIdForCurrentTrainings(long id);
	
}
