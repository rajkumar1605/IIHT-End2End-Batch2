package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.AllowableTechnology;
import io.cts.mod.sbapp.repository.AllowableTechnologyRepository;

@Service
public class AllowableTechnologyServiceImpl implements AllowableTechnologyService {
	
	@Autowired
	private AllowableTechnologyRepository repository;

	@Override
	public AllowableTechnology insertAllowableTechnology(AllowableTechnology tech) {
		return repository.save(tech);
	}

	@Override
	public List<AllowableTechnology> getAllAllowableTechnology() {
		List<AllowableTechnology> techs=new ArrayList<>();
		repository.findAll().forEach(techs::add);
		return techs;
	}

	@Override
	public Optional<AllowableTechnology> findAllowableTechById(long id) {
		return repository.findById(id);
	}

	@Override
	public void updateAllowableTechnologyDetails(long id, AllowableTechnology tech) {
		
		Optional<AllowableTechnology> allowableData=findAllowableTechById(id);
		
		if(allowableData.isPresent()) {

			AllowableTechnology awt=allowableData.get();
			String name,max,min;
			name=tech.getTechName();
			max=tech.getMaxDuration();
			min=tech.getMinDuration();
					
			if(name!=null) {
				awt.setTechName(name);
			}
			else {
				awt.setTechName(awt.getTechName());
			}
			if(max!=null) {
				awt.setMaxDuration(max);
			}
			else {
				awt.setMaxDuration(awt.getMaxDuration());
			}
			if(min!=null) {
				awt.setMinDuration(min);
			}
			else {
				awt.setMinDuration(awt.getMinDuration());
			}
			repository.save(awt);		
		}
		
	}

	@Override
	public boolean deleteAllowableTechById(long id) {	
			repository.deleteById(id);	
			Optional<AllowableTechnology> dalw = findAllowableTechById(id);
			if(dalw.isPresent()) {
				return false;
			}
			else {
				return true;
			}
	}

}
