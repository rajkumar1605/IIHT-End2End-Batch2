package io.cts.mod.sbapp;

import java.text.ParseException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainApplication {

	public static void main(String[] args) throws ParseException {
		
/*		servlet container */
		SpringApplication.run(MainApplication.class, args);		 
	
	}
}


