package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.MentorStatus;

public interface MentorStatusService {
	
	public MentorStatus insertMentorStatus(MentorStatus status);
	public Optional<MentorStatus> findMentorStatusById(long id);
	public boolean deleteMenorStatusById(long id);
	
	public List<MentorStatus> getAllMentorsStatus();
	public void updateMentorStatus(long id,MentorStatus mtrStatus);

}
