package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.AllowableTechnology;
import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.model.UserSearchResult;

@Service
public class UserSearchServiceImpl implements UserSearchService {
	
	@Autowired
	private TrainingsService trainingService;
	
	@Autowired
	private AllowableTechnologyService allowService;
	
	@Autowired
	private MentorService mentorService;

	@Override
	public List<UserSearchResult> getUserSearchResult(String timeValue, String courseName) {
				
		List<UserSearchResult> usr=new ArrayList<UserSearchResult>();
		UserSearchResult us=new UserSearchResult();
		List<Trainings> list=new ArrayList<>();
		
		List<AllowableTechnology> allowableData = allowService.getAllAllowableTechnology();
	
		for(AllowableTechnology allowable:allowableData) {
			
			if(allowable.getTechName().equalsIgnoreCase(courseName)){
								
				long ctId=allowable.getId();
			
				if(timeValue.equals("9")) {
					list = trainingService.getByCreatedStatusAndTrainingIdAndStartTime("Created", ctId,"9:00 AM");
				}
				else if(timeValue.equals("1")) {
					 list=trainingService.getByCreatedStatusAndTrainingIdAndStartTime("Created", ctId, "1:00 PM");
				}
				else if(timeValue.equals("5")) {
					list=trainingService.getByCreatedStatusAndTrainingIdAndStartTime("Created", ctId, "5:00 PM");
				}
				else if(timeValue.equals("10")) {
					list=trainingService.getByCreatedStatusAndTrainingIdAndStartTime("Created", ctId, "9:00 PM");
				}
				
				for(Trainings lt:list) {
					long mentorId = lt.getMentorId();
					Optional<Mentor> mentor = mentorService.findMentorById(mentorId);
					us.setMentorName(mentor.get().getFirstName()+" "+mentor.get().getLastName());
					us.setRating(lt.getCurrentRating());
					us.setFeeCharged(lt.getExpectedAmount());  /* Plus commision */
					us.setYoe(mentor.get().getYearsOfExperience());
					us.setNumOfSpecificTech(0);    /* Fill afterwards */
					us.setTotalNumOfTrainings(0);
					
					usr.add(us);
				}
	
			}
		}
			
		return usr;
		
	}

}
