package io.cts.mod.sbapp.service;

import java.util.List;
import java.util.Optional;

import io.cts.mod.sbapp.bean.AllowableTechnology;

public interface AllowableTechnologyService {
	
	public AllowableTechnology insertAllowableTechnology(AllowableTechnology tech);
	public List<AllowableTechnology> getAllAllowableTechnology();
	public Optional<AllowableTechnology> findAllowableTechById(long id);
	public void updateAllowableTechnologyDetails(long id,AllowableTechnology tech);
	public boolean deleteAllowableTechById(long id);	
	
}