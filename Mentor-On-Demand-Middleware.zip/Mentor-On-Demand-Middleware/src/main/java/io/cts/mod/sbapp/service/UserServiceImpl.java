package io.cts.mod.sbapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.cts.mod.sbapp.bean.AllowableTechnology;
import io.cts.mod.sbapp.bean.Mentor;
import io.cts.mod.sbapp.bean.Trainings;
import io.cts.mod.sbapp.bean.User;
import io.cts.mod.sbapp.bean.UserPayments;
import io.cts.mod.sbapp.model.MentorCreatedTrainings;
import io.cts.mod.sbapp.model.UserConfirmedTrainings;
import io.cts.mod.sbapp.model.UserLearntTrainings;
import io.cts.mod.sbapp.model.UserOngoingTrainings;
import io.cts.mod.sbapp.model.UserProposedTrainings;
import io.cts.mod.sbapp.repository.MentorRepository;
import io.cts.mod.sbapp.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repository;

	@Autowired
	private TrainingsService trainingService;
	
	@Autowired
	private MentorService mentorService;

//	@Autowired
//	private UserPaymentsService paymentService;

	@Autowired
	private AllowableTechnologyService allowService;

	@Override
	public User insertUser(User user) {
		return repository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = new ArrayList<>();
		repository.findAll().forEach(users::add);
		return users;
	}

	@Override
	public Optional<User> findUserById(long id) {
		return repository.findById(id);
	}

	@Override
	public void updateUserDetails(long id, User user) {
		Optional<User> userData = findUserById(id);

		if (userData.isPresent()) {
			User usr = userData.get();

			String contactNumber, active;
			contactNumber = user.getContactNumber();
			active = user.getActive();
			if (contactNumber != null) {
				usr.setContactNumber(contactNumber);
			} else {
				usr.setContactNumber(usr.getContactNumber());
			}
			if (active != null) {
				usr.setActive(active);
			} else {
				usr.setActive(usr.getActive());
			}

			usr.setFirstName(usr.getFirstName());
			usr.setLastName(usr.getLastName());
			usr.setGender(usr.getGender());
			usr.setAreaOfInterest(usr.getAreaOfInterest());
			usr.setEducation(usr.getEducation());
			usr.setEmailId(usr.getEmailId());
			usr.setPassword(usr.getPassword());
			usr.setSecurityQuestion(usr.getSecurityQuestion());
			usr.setOwnSecurityQuestion(usr.getOwnSecurityQuestion());
			usr.setSecurityAnswer(usr.getSecurityAnswer());
		}

	}

	@Override
	public int deleteUserById(long id) {
		/* delete all records of this user(add later) */
		int flag = 0;
		Optional<User> currentUser = findUserById(id);

		if (currentUser.isPresent()) {
			repository.deleteById(id);
			flag = 1;
		}
		return flag;
	}

	@Override
	public void createTraining(long uid, long mid, long cid) {
		
        Trainings tr = new Trainings();

		Optional<Trainings> trainingData = trainingService.getByCreatedStatusAndMentorIdAndTrainingId("Created", mid,
				cid);
	
		if (trainingData.isPresent()) {

			Trainings training = trainingData.get();
			
			List<Trainings> specificCourseDetails = getAllDataOfSpecificCourse(training.getCourseTechId(),training.getMentorId() );
			int numberOfAttendees=specificCourseDetails.size();
			
			tr.setUserId(uid);   
			tr.setMentorId(training.getMentorId());
			tr.setCourseTechId(training.getCourseTechId());
			tr.setCourseFacilities(training.getCourseFacilities());
			tr.setNumOfAttendees(numberOfAttendees);
			tr.setCourseDuration(training.getCourseDuration());
			tr.setCurrentRating(training.getCurrentRating());
			tr.setStatus("Proposed");
			tr.setProgress(training.getProgress());
			tr.setMaybeStartTime(training.getMaybeStartTime());
			tr.setStartDate(training.getStartDate());
			tr.setEndDate(training.getEndDate());
			tr.setStartTime(training.getStartTime());
			tr.setEndTime(training.getEndTime());
			tr.setExpectedAmount(training.getExpectedAmount());
			tr.setAmountReceived(training.getAmountReceived());

			Trainings userTraining = trainingService.insertFromUser(tr);
	
//			long userTrainingId = userTraining.getId();

		}

	}

	@Override
	public List<UserOngoingTrainings> getCurrentTrainings(long uid) {
		List<UserOngoingTrainings> currentTrainingsList = new ArrayList<UserOngoingTrainings>();

		List<Trainings> trainings_list = trainingService.getByInprogressStatusAndUserId("Inprogress",
				uid); /* insert user id on the runtime when getting from login */

		for (Trainings trainings : trainings_list) {
			UserOngoingTrainings ucd = new UserOngoingTrainings();
			
			ucd.setTrainingId(trainings.getId());
			
			Optional<AllowableTechnology> allowableCourseData = allowService
					.findAllowableTechById(trainings.getCourseTechId());

			if (allowableCourseData.isPresent()) {

				AllowableTechnology allowableCourse = allowableCourseData.get();
				ucd.setCourseName(allowableCourse.getTechName());

			}
			
			Optional<Mentor> mentorData = mentorService.findMentorById(trainings.getMentorId());
			if(mentorData.isPresent()) {
				Mentor mentor = mentorData.get();	
				ucd.setMentorName(mentor.getFirstName()+" "+mentor.getLastName());
			}
			
			
			ucd.setProgress(trainings.getProgress());
			ucd.setDuration(trainings.getCourseDuration());
			ucd.setDateOfCompletion(trainings.getEndDate());

			currentTrainingsList.add(ucd);

		}

		return currentTrainingsList;

	}

	@Override
	public List<UserConfirmedTrainings> getConfirmedTrainings(long uid) {
		List<UserConfirmedTrainings> confirmedTrainingsList = new ArrayList<UserConfirmedTrainings>();

		List<Trainings> trainings_list = trainingService.getByStatusAndUserId("Confirmed",
				uid); /* insert user id on the runtime when getting from login */

		for (Trainings trainings : trainings_list) {
			UserConfirmedTrainings uct = new UserConfirmedTrainings();
			
			Optional<AllowableTechnology> allowableCourseData = allowService
					.findAllowableTechById(trainings.getCourseTechId());

			if (allowableCourseData.isPresent()) {

				AllowableTechnology allowableCourse = allowableCourseData.get();
				uct.setCourseName(allowableCourse.getTechName());

			}
			
			Optional<Mentor> mentorData = mentorService.findMentorById(trainings.getMentorId());
			if(mentorData.isPresent()) {
				Mentor mentor = mentorData.get();	
				uct.setMentorName(mentor.getFirstName()+" "+mentor.getLastName());
			}
						
			uct.setDuration(trainings.getCourseDuration());
			uct.setStartDate(trainings.getStartDate());
			uct.setMoney(trainings.getExpectedAmount());  /* Add Commision here */
			confirmedTrainingsList.add(uct);

		}

		return confirmedTrainingsList;

	}

	@Override
	public List<UserProposedTrainings> getProposedTrainings(long uid) {
		List<UserProposedTrainings> proposedTrainingsList = new ArrayList<UserProposedTrainings>();

		List<Trainings> trainings_list = trainingService.getByStatusAndUserId("Proposed",
				uid); /* insert user id on the runtime when getting from login */

		for (Trainings trainings : trainings_list) {
			UserProposedTrainings upt = new UserProposedTrainings();
			
			Optional<AllowableTechnology> allowableCourseData = allowService
					.findAllowableTechById(trainings.getCourseTechId());

			if (allowableCourseData.isPresent()) {

				AllowableTechnology allowableCourse = allowableCourseData.get();
				upt.setCourseName(allowableCourse.getTechName());

			}
			
			Optional<Mentor> mentorData = mentorService.findMentorById(trainings.getMentorId());
			if(mentorData.isPresent()) {
				Mentor mentor = mentorData.get();	
				upt.setMentorName(mentor.getFirstName()+" "+mentor.getLastName());
			}
						
			upt.setDuration(trainings.getCourseDuration());
			upt.setMoneyToBePaid(trainings.getExpectedAmount());  /* Add Commision here */
	
			proposedTrainingsList.add(upt);

		}

		return proposedTrainingsList;

	}

	@Override
	public List<UserLearntTrainings> getCompletedTrainings(long uid) {
		List<UserLearntTrainings> completedTrainingsList = new ArrayList<UserLearntTrainings>();

		List<Trainings> trainings_list = trainingService.getByStatusAndUserId("Completed",
				uid); /* insert user id on the runtime when getting from login */

		for (Trainings trainings : trainings_list) {
			UserLearntTrainings ult = new UserLearntTrainings();
			
			Optional<AllowableTechnology> allowableCourseData = allowService
					.findAllowableTechById(trainings.getCourseTechId());

			if (allowableCourseData.isPresent()) {

				AllowableTechnology allowableCourse = allowableCourseData.get();
				ult.setCourseName(allowableCourse.getTechName());

			}
			
			Optional<Mentor> mentorData = mentorService.findMentorById(trainings.getMentorId());
			if(mentorData.isPresent()) {
				Mentor mentor = mentorData.get();	
				ult.setMentorName(mentor.getFirstName()+" "+mentor.getLastName());
			}
						
			ult.setDuration(trainings.getCourseDuration());
			ult.setDateOfCompletion(trainings.getEndDate());
			ult.setMoneyPaid(trainings.getAmountReceived());
			
			completedTrainingsList.add(ult);

		}

		return completedTrainingsList;
	}
	
	@Override
	public void updateProgress(long tid, Trainings train) {
		
		if(train.getProgress()!=4)/*value from slidebar */ {   
						
			trainingService.updateTrainingsDetails(tid,train);
		}else if(train.getProgress()==4) {
			train.setStatus("Completed");
			trainingService.updateTrainingsDetails(tid,train);
		}
	}
	
	@Override
	public List<UserPayments> getUserPayment() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Trainings> getAllDataOfSpecificCourse(long ctId, long mid) {
		return trainingService.getByCourseTechIdAndMentorId(ctId, mid);
	}

	

}
