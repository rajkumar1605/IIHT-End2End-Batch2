package io.cts.mod.sbapp.model;

public class MentorCreatedTrainings {

	private long mentorId;
	private String courseName;
	private int durationOfCoures;
	private int averageRating;
	private double expectedPayment;

	public MentorCreatedTrainings() {
		super();
	}

	public MentorCreatedTrainings(long mentorId, String courseName, int durationOfCoures, int averageRating,
			double expectedPayment) {
		super();
		this.mentorId = mentorId;
		this.courseName = courseName;
		this.durationOfCoures = durationOfCoures;
		this.averageRating = averageRating;
		this.expectedPayment = expectedPayment;
	}

	public long getMentorId() {
		return mentorId;
	}

	public String getCourseName() {
		return courseName;
	}

	public int getDurationOfCoures() {
		return durationOfCoures;
	}

	public int getAverageRating() {
		return averageRating;
	}

	public double getExpectedPayment() {
		return expectedPayment;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setDurationOfCoures(int durationOfCoures) {
		this.durationOfCoures = durationOfCoures;
	}

	public void setAverageRating(int averageRating) {
		this.averageRating = averageRating;
	}

	public void setExpectedPayment(double expectedPayment) {
		this.expectedPayment = expectedPayment;
	}

	@Override
	public String toString() {
		return "MentorCreatedTrainings [mentorId=" + mentorId + ", courseName=" + courseName + ", durationOfCoures="
				+ durationOfCoures + ", averageRating=" + averageRating + ", expectedPayment=" + expectedPayment + "]";
	}

}
