package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "mentor_status_table")
public class MentorStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Size(max = 50)
	@Column(name = "active")
	private String active; // blocked or unblocked

	@NonNull
	@Column(name = "course_id")
	private long courseId; // Take all the details of the course and keep it as an id

	@NonNull
	@Min(value = 0, message = "Must be equal or greater than 0")
	@Column(name = "total_number_of_training")
	private int totalTraining;

	@NonNull
	@Min(value = 0, message = "Must be equal or greater than 0")
	@Column(name = "number_of_training_on_specific_technology")
	private int numSpecificTech;

	public MentorStatus() {
		super();
	}

	public MentorStatus(long id, @Size(max = 50) String active, long courseId,
			@Min(value = 0, message = "Must be equal or greater than 0") int totalTraining,
			@Min(value = 0, message = "Must be equal or greater than 0") int numSpecificTech) {
		super();
		this.id = id;
		this.active = active;
		this.courseId = courseId;
		this.totalTraining = totalTraining;
		this.numSpecificTech = numSpecificTech;
	}

	public long getId() {
		return id;
	}

	public String getActive() {
		return active;
	}

	public long getCourseId() {
		return courseId;
	}

	public int getTotalTraining() {
		return totalTraining;
	}

	public int getNumSpecificTech() {
		return numSpecificTech;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}

	public void setTotalTraining(int totalTraining) {
		this.totalTraining = totalTraining;
	}

	public void setNumSpecificTech(int numSpecificTech) {
		this.numSpecificTech = numSpecificTech;
	}

	@Override
	public String toString() {
		return "MentorStatus [id=" + id + ", active=" + active + ", courseId=" + courseId + ", totalTraining="
				+ totalTraining + ", numSpecificTech=" + numSpecificTech + "]";
	}

}
