package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "mentor_details_table")
public class Mentor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Size(max = 50)
	@Column(name = "first_name")
	private String firstName;

	@NonNull
	@Size(max = 50)
	@Column(name = "last_name")
	private String lastName;

	@NonNull
	@Size(max = 50)
	@Column(name = "gender")
	private String gender;

	@NonNull
	@Size(max = 50)
	@Column(name = "education")
	private String education;

	@NonNull
	@Size(max = 50)
	@Column(name = "time_zone")
	private String timeZone;

	@NonNull
	@Size(max = 50)
	@Column(name = "work_timing")
	private String workTiming;

	@NonNull
	@Size(max = 50)
	@Column(name = "list_of_skills")
	private String listOfSkills;

	@NonNull
	@Size(max = 50)
	@Column(name = "facilities")
	private String facilities;

	@NonNull
	@Min(value=1, message="Must be equal or greater than 1")  
    @Max(value=70, message="Must be equal or less than 70")  
	@Column(name = "years_of_experience")
	private int yearsOfExperience;

	@NonNull
	@Size(max = 50)
	@Column(name = "linkedin_url")
	private String linkedinURL;

	@NonNull
	@Size(max = 50)
	@Column(name = "contact_number")
	private String contactNumber;

	@NonNull
	@Size(max = 50)
	@Column(name = "user_name_email")
	private String userNameEmail;

	@NonNull
	@Size(max = 50)
	@Column(name = "password")
	private String password;

	@NonNull
	@Size(max = 50)
	@Column(name = "security_question")
	private String securityQuestion;

	@NonNull
	@Size(max = 50)
	@Column(name = "own_security_question")
	private String ownSecurityQuestion;

	@NonNull
	@Size(max = 50)
	@Column(name = "security_answer")
	private String securityAnswer;

	@NonNull
	@Column(name = "mentor_status")
	private long mentorStatus;

	// @NonNull
	// @Size(max = 50)
	// @Column(name = "reg_datetime")
	// private String reg_datetime;
	//
	// @NonNull
	// @Size(max = 50)
	// @Column(name = "reg_code")
	// private String reg_code;

	public Mentor() {
		super();
	}

	public Mentor(long id, @Size(max = 50) String firstName, @Size(max = 50) String lastName,
			@Size(max = 50) String gender, @Size(max = 50) String education, @Size(max = 50) String timeZone,
			@Size(max = 50) String workTiming, @Size(max = 50) String listOfSkills, @Size(max = 50) String facilities,
			@Size(max = 50) int yearsOfExperience, @Size(max = 50) String linkedinURL,
			@Size(max = 50) String contactNumber, @Size(max = 50) String userNameEmail, @Size(max = 50) String password,
			@Size(max = 50) String securityQuestion, @Size(max = 50) String ownSecurityQuestion,
			@Size(max = 50) String securityAnswer, @Size(max = 50) long mentorStatus) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.education = education;
		this.timeZone = timeZone;
		this.workTiming = workTiming;
		this.listOfSkills = listOfSkills;
		this.facilities = facilities;
		this.yearsOfExperience = yearsOfExperience;
		this.linkedinURL = linkedinURL;
		this.contactNumber = contactNumber;
		this.userNameEmail = userNameEmail;
		this.password = password;
		this.securityQuestion = securityQuestion;
		this.ownSecurityQuestion = ownSecurityQuestion;
		this.securityAnswer = securityAnswer;
		this.mentorStatus = mentorStatus;
	}

	public long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getGender() {
		return gender;
	}

	public String getEducation() {
		return education;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public String getWorkTiming() {
		return workTiming;
	}

	public String getListOfSkills() {
		return listOfSkills;
	}

	public String getFacilities() {
		return facilities;
	}

	public int getYearsOfExperience() {
		return yearsOfExperience;
	}

	public String getLinkedinURL() {
		return linkedinURL;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public String getUserNameEmail() {
		return userNameEmail;
	}

	public String getPassword() {
		return password;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public String getOwnSecurityQuestion() {
		return ownSecurityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public long getMentorStatus() {
		return mentorStatus;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public void setWorkTiming(String workTiming) {
		this.workTiming = workTiming;
	}

	public void setListOfSkills(String listOfSkills) {
		this.listOfSkills = listOfSkills;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public void setLinkedinURL(String linkedinURL) {
		this.linkedinURL = linkedinURL;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setUserNameEmail(String userNameEmail) {
		this.userNameEmail = userNameEmail;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public void setOwnSecurityQuestion(String ownSecurityQuestion) {
		this.ownSecurityQuestion = ownSecurityQuestion;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	public void setMentorStatus(long mentorStatus) {
		this.mentorStatus = mentorStatus;
	}

	@Override
	public String toString() {
		return "Mentor [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender
				+ ", education=" + education + ", timeZone=" + timeZone + ", workTiming=" + workTiming
				+ ", listOfSkills=" + listOfSkills + ", facilities=" + facilities + ", yearsOfExperience="
				+ yearsOfExperience + ", linkedinURL=" + linkedinURL + ", contactNumber=" + contactNumber
				+ ", userNameEmail=" + userNameEmail + ", password=" + password + ", securityQuestion="
				+ securityQuestion + ", ownSecurityQuestion=" + ownSecurityQuestion + ", securityAnswer="
				+ securityAnswer + ", mentorStatus=" + mentorStatus + "]";
	}

}
