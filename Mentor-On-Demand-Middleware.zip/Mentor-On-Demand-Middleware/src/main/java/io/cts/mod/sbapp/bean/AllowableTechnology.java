package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "allowable_technology_table")
public class AllowableTechnology {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Size(max = 50)
	@Column(name = "tech_name")
	private String techName;

	@NonNull
	@Size(max = 50)
	@Column(name = "max_allowable_duration")
	private String maxDuration;

	@NonNull
	@Size(max = 50)
	@Column(name = "min_allowable_duration")
	private String minDuration;

	public AllowableTechnology() {
		super();
	}

	public AllowableTechnology(long id, @Size(max = 50) String techName, @Size(max = 50) String maxDuration,
			@Size(max = 50) String minDuration) {
		super();
		this.id = id;
		this.techName = techName;
		this.maxDuration = maxDuration;
		this.minDuration = minDuration;
	}

	public long getId() {
		return id;
	}

	public String getTechName() {
		return techName;
	}

	public String getMaxDuration() {
		return maxDuration;
	}

	public String getMinDuration() {
		return minDuration;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setTechName(String techName) {
		this.techName = techName;
	}

	public void setMaxDuration(String maxDuration) {
		this.maxDuration = maxDuration;
	}

	public void setMinDuration(String minDuration) {
		this.minDuration = minDuration;
	}

	@Override
	public String toString() {
		return "AllowableTechnology [id=" + id + ", techName=" + techName + ", maxDuration=" + maxDuration
				+ ", minDuration=" + minDuration + "]";
	}
	
}
