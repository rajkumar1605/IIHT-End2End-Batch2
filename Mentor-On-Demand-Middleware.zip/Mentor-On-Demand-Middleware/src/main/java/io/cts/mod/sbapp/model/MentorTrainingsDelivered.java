package io.cts.mod.sbapp.model;

public class MentorTrainingsDelivered {

	private long mentorId;
	private String courseName;
	private int rating;
	private String dateOfCompletion;
	private String StatusOfPayment;
	private double earning; /* payment table */

	public MentorTrainingsDelivered() {
		super();

	}

	public MentorTrainingsDelivered(long mentorId, String courseName, int rating, String dateOfCompletion,
			String statusOfPayment, double earning) {
		super();
		this.mentorId = mentorId;
		this.courseName = courseName;
		this.rating = rating;
		this.dateOfCompletion = dateOfCompletion;
		StatusOfPayment = statusOfPayment;
		this.earning = earning;
	}

	public long getMentorId() {
		return mentorId;
	}

	public String getCourseName() {
		return courseName;
	}

	public int getRating() {
		return rating;
	}

	public String getDateOfCompletion() {
		return dateOfCompletion;
	}

	public String getStatusOfPayment() {
		return StatusOfPayment;
	}

	public double getEarning() {
		return earning;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public void setDateOfCompletion(String dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}

	public void setStatusOfPayment(String statusOfPayment) {
		StatusOfPayment = statusOfPayment;
	}

	public void setEarning(double earning) {
		this.earning = earning;
	}

	@Override
	public String toString() {
		return "MentorTrainingsDelivered [mentorId=" + mentorId + ", courseName=" + courseName + ", rating=" + rating
				+ ", dateOfCompletion=" + dateOfCompletion + ", StatusOfPayment=" + StatusOfPayment + ", earning="
				+ earning + "]";
	}

}
