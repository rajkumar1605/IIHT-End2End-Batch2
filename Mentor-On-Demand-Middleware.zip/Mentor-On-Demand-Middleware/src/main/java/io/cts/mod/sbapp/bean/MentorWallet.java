package io.cts.mod.sbapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

@Entity
@Table(name="mentor_wallet_table")
public class MentorWallet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@NonNull
	@Column(name = "withdrawn_money")
	private double withdrawnMoney;

	@NonNull
	@Column(name = "wallet")
	private double wallet;

	@NonNull
	@Column(name = "mentor_id")
	private long mentorId;

	public MentorWallet() {
		super();
	}

	public MentorWallet(double withdrawnMoney, double wallet, long mentorId) {
		super();
		this.withdrawnMoney = withdrawnMoney;
		this.wallet = wallet;
		this.mentorId = mentorId;
	}

	public double getWithdrawnMoney() {
		return withdrawnMoney;
	}

	public double getWallet() {
		return wallet;
	}

	public long getMentorId() {
		return mentorId;
	}

	public void setWithdrawnMoney(double withdrawnMoney) {
		this.withdrawnMoney = withdrawnMoney;
	}

	public void setWallet(double wallet) {
		this.wallet = wallet;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}

	@Override
	public String toString() {
		return "MentorWallet [withdrawnMoney=" + withdrawnMoney + ", wallet=" + wallet + ", mentorId=" + mentorId + "]";
	}

}
