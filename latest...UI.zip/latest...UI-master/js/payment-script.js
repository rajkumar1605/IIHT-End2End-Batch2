document.getElementById("payment-form").addEventListener('submit',function(){

});