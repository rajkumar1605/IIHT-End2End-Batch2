// var myVar;

// function myFunction() {
//   myVar = setTimeout(showPage, 1000);
// }

// function showPage() {
//   document.getElementById("loader").style.display = "none";
//   document.getElementById("wait-for-preload").style.display = "block";
//   document.getElementById("ok").style.display = "block";
// }