import { Component, OnInit } from '@angular/core';
import { User } from 'src/model/user';
import { Router } from '@angular/router';
import { UserAuthService } from 'src/services/user-auth.service';

@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {

  hidden: boolean=false;
  username: String;
  email: String;
  password: String;
  rPassword: String;
  users: User[];
  checkAlert: boolean= false;
  checkUpdate: boolean=true;
  checkEmail: boolean=false;
  alertValue: String="";
  flag: number=0;
  flag1: number=0;

  userId: number;
  
  constructor(private router: Router, private loginService: UserAuthService) { }

  ngOnInit() {
    this.hidden=false;
    this.loginService.getUsers().subscribe(response => this.users = response, error => alert(`${error.message}\nWaiting for response from server`));

    let userId = localStorage.getItem("userId");
    if (!userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['sign-in']);
      return;
    }
    this.userId = parseInt(userId);
  }

  onSubmit() {
    if(this.disAbleCheck()){
      if(this.onCheckEmail()){
      
      let user = new User(this.username, this.email, this.password);

      this.hidden=true;
      this.loginService.setUpdateUserDetails(this.userId,user).subscribe();
    }
  }    
  }

  forReload(){
    location.reload(true);
  }

  onCheckUserName(){
    if(this.username){ /*check for undefined(empty*/
      for (let i = 0; i < this.users.length; i++) {
        if ( this.users[i].name === this.username ) {
          this.flag=1;
          break;
        } 
      }
      if(this.flag===0){
          this.checkAlert=true;
          this.alertValue="";
          this.alertValue="You can use this User Name !";
          this.checkUpdate=false;
          this.flag=0; 
      }else{
        this.checkAlert = true;
        this.alertValue="";
        this.alertValue="User Name already taken !";
        this.flag=0; 
      }
    
    }else{
      this.checkAlert=true;
      this.alertValue="";
      this.alertValue="User Name is empty !";  
    }
    
  }

  onCheckEmail(){
    if(this.email){
      for (let i = 0; i < this.users.length; i++) {
        if ( this.users[i].email === this.email ) {
          this.flag1=1;
        } 
      }
      if(this.flag1===0){
        this.checkEmail=false;
        return true;
      }else{
        this.checkEmail=true;
        this.flag1=0;
        return false;
      }
    }
  }


disAbleCheck(){
  if(this.username){
    if(this.password){
      if(this.rPassword){
        if(this.email){
          return true;
        }else{
          return false;
        }
      }else{
        return false;
      }
    }else{
      return false;
    }
  }else{
    return false;
  }
}
}
