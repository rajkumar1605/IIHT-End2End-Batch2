import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/model/user';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
 
  baseUrl = 'http://localhost:8989/pixogramsocio/pixogramService';
  
  constructor(private http: HttpClient) { }

  getUsers(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/users`);
  }

  registerUser(user: User): Observable<any> {
    return this.http.post(`${this.baseUrl}/user/create`, user);
  }

  getUserById(userId: number): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/user/${userId}`);
  }
  
  searchByName(name:String):Observable<any>
  {
    return this.http.get<any>(`${this.baseUrl}/username/${name}`);
  }

  setUpdateUserDetails(userId: number,user: User): Observable<Object> {
     return this.http.put(`${this.baseUrl}/user/update/${userId}`,user);
  }

}
