import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/services/user-auth.service';
import { Router } from '@angular/router';
import { User } from 'src/model/user';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  users : User;
  name:String;


  constructor(private router: Router, private loginService: UserAuthService) { }

  ngOnInit() {
   
  }
  onSubmit()
  {
   this.searchDetails();
  }
  searchDetails() {
    this.loginService.searchByName(this.name).subscribe(users=>this.users=users);
    // console.log(this.users);
  }

}
