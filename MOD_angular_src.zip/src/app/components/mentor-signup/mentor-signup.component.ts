import { MentorService } from './../../service/mentor.service';
import { Component, OnInit } from '@angular/core';
import { MentorSignup } from './MentorSignupPojo';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  mentor: MentorSignup = new MentorSignup();
  submitted = false;

  constructor( private mentorService : MentorService ) { }

  ngOnInit() {
  }

  onSubmit(){

    // console.log(this.mentor);
    // this.submitted = true;

    // this.mentorService.insertMentor(this.mentor).subscribe(data => console.log(data), error => console.log(error));

    // this.mentor = new MentorSignup();
    
  }

}
