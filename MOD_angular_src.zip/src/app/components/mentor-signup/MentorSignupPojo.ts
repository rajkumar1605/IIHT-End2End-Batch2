export class MentorSignup{
    firstName: string;
    lastName: string;
    gender: string;
    education: string;
    timeZone: string;
    workTiming: string;
    listOfSkillls: string;
    facilities: string;
    yearsOfExperience: number;
    linkedinURL: string;
    contactNumber: string;
    userNameEmail: string;
    password: string;
    securityQuestion: string;
    ownSecurityQuestion: string;
    securityAnswer: string;
   
}