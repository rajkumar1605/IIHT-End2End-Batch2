import { MentorService } from './../../service/mentor.service';
import { Component, OnInit } from '@angular/core';

import { Observable } from 'rxjs';

@Component({
  selector: 'app-mentor-homepage',
  templateUrl: './mentor-homepage.component.html',
  styleUrls: ['./mentor-homepage.component.css']
})
export class MentorHomepageComponent implements OnInit {
  reloadData() {
    throw new Error("Method not implemented.");
  }

  mentorCurrentTrainings: object;
  mentorCompletedTrainings: object;
  mentorPaymentDetails: object;

  constructor(private data: MentorService) { }

  ngOnInit() {

    // this.data.getCurrentTrainings().subscribe( data => this.mentorCurrentTrainings=data );

    // this.data.getCompletedtrainings().subscribe( data => this.mentorCompletedTrainings=data );

    // this.data.getMentorPaymentDetails().subscribe( data => this.mentorPaymentDetails=data );

  }

}
