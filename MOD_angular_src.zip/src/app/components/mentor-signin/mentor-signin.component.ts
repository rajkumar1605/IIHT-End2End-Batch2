import { MentorHomepageComponent } from './../mentor-homepage/mentor-homepage.component';
import { MentorService } from './../../service/mentor.service';
import { Component, OnInit } from '@angular/core';
import { MentorSignin } from './MentorSignUpPojo';
import { Router } from '@angular/router';



@Component({
  selector: 'app-mentor-signin',
  templateUrl: './mentor-signin.component.html',
  styleUrls: ['./mentor-signin.component.css']
})
export class MentorSigninComponent implements OnInit {

  mentor: MentorSignin = new MentorSignin();
   

  constructor( private router:Router ) { }

  ngOnInit() {
  }
  
  onSubmit(){
    // console.log(this.mentor);
    this.router.navigate(['/mentor-homepage']);
  }

}
