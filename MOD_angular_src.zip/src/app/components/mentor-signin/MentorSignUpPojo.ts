export class MentorSignin{
    mentorEmail: string;
    mentorPassword: string;
}