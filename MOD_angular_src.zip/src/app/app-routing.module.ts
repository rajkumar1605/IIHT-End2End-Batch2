import { UserSearchResultComponent } from './components/user-search-result/user-search-result.component';
import { AdminSigninComponent } from './components/admin-signin/admin-signin.component';
import { AdminHomepageComponent } from './components/admin-homepage/admin-homepage.component';
import { UserHomepageComponent } from './components/user-homepage/user-homepage.component';
import { UserSignupComponent } from './components/user-signup/user-signup.component';
import { UserSigninComponent } from './components/user-signin/user-signin.component';
import { MentorHomepageComponent } from './components/mentor-homepage/mentor-homepage.component';
import { MentorSigninComponent } from './components/mentor-signin/mentor-signin.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MentorSignupComponent } from './components/mentor-signup/mentor-signup.component';
import { IndexComponent } from './components/index/index.component';
import { PaymentGatewayComponent } from './components/payment-gateway/payment-gateway.component';

const routes: Routes = [
  { path:'' , component:IndexComponent },
  { path:'index',component:IndexComponent },

  { path:'user-signin',component:UserSigninComponent },
  { path:'user-signup',component:UserSignupComponent },
  { path:'user-homepage',component:UserHomepageComponent },
  { path:'user-search-result',component:UserSearchResultComponent },

  { path:'mentor-signin', component:MentorSigninComponent },
  { path:'mentor-signup', component:MentorSignupComponent },
  { path:'mentor-homepage', component:MentorHomepageComponent },

  { path:'admin-signin',component:AdminSigninComponent },
  { path:'admin-homepage',component:AdminHomepageComponent },

  { path:'payment-gateway',component:PaymentGatewayComponent }

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
