import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MentorSigninComponent } from './components/mentor-signin/mentor-signin.component';
import { MentorHomepageComponent } from './components/mentor-homepage/mentor-homepage.component';
import { HttpClientModule } from '@angular/common/http';
import { MentorService } from './service/mentor.service';
import { MentorSignupComponent } from './components/mentor-signup/mentor-signup.component';
import { UserSigninComponent } from './components/user-signin/user-signin.component';
import { UserSignupComponent } from './components/user-signup/user-signup.component';
import { UserHomepageComponent } from './components/user-homepage/user-homepage.component';
import { UserSearchResultComponent } from './components/user-search-result/user-search-result.component';
import { PaymentGatewayComponent } from './components/payment-gateway/payment-gateway.component';
import { IndexComponent } from './components/index/index.component';
import { AdminSigninComponent } from './components/admin-signin/admin-signin.component';
import { AdminHomepageComponent } from './components/admin-homepage/admin-homepage.component';
import { UserService } from './service/user.service';
import { AdminService } from './service/admin.service';

@NgModule({
  declarations: [
    AppComponent,
    MentorSigninComponent,
    MentorHomepageComponent,
    MentorSignupComponent,
    UserSigninComponent,
    UserSignupComponent,
    UserHomepageComponent,
    UserSearchResultComponent,
    PaymentGatewayComponent,
    IndexComponent,
    AdminSigninComponent,
    AdminHomepageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    AdminService,
    UserService,
    MentorService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
