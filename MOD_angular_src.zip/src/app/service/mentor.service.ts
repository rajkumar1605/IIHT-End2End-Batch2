import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  constructor(private http: HttpClient) { }

  // getCurrentTrainings(){
  //   return this.http.get('http://localhost:8082/mentor/getcurrenttrainings');
  // }

  // getCompletedtrainings(){
  //   return this.http.get('http://localhost:8082/mentor/getcompletedtrainings');
  // }

  // getMentorPaymentDetails(){
  //   return this.http.get('http://localhost:8082/mentor/getmentorpaymentdetails');
  // }

  // insertMentor(mentor: Object) {
  //   return this.http.post('http://localhost:8082/mentor/insertmentor',mentor);
  // }

}
